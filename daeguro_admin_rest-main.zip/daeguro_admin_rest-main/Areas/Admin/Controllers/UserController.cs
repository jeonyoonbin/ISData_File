﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        /// <summary>
        /// 사용자명 검색
        /// </summary>
        /// <remarks>
        /// mCode 회원사: 1.테스트, 2. 운영, 3. 회계 <br/>
        /// working 근무구분: 빈값.전체, 1.재직, 3.휴직, 5.퇴직 <br/>
        /// keyword 키워드 검색(이름) <br/>
        /// ucode 단일 사용자 조회용 ucode <br/>
        /// [response] <br/>
        /// uCode 코드 <br/>
        /// name 이름 <br/>
        /// memo 메모 <br/>
        /// </remarks>
        [HttpGet("getNameList")]
        public async Task<IActionResult> getNameList(string mCode, string working, string keyword, string ucode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<UserName> items = new List<UserName>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.GET_NAME_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("in_working", OracleDbType.Varchar2, 1).Value = working;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 30).Value = keyword;
            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    UserName item = new UserName
                    {
                        uCode = rd["ucode"].ToString(),
                        name = rd["user_name"].ToString(),
                        memo = rd["memo"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/getNameList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 사용자 관리 - 목록 조회
        /// </summary>
        /// <remarks>
        /// mCode 회원사(필수): 1.테스트, 2. 운영, 3. 회계 <br/>
        /// level 사용등급: 0. 관리자, 5. 조회자, 6. 개인정보취급자 <br/>
        /// working 근무구분: 1.재직, 3.휴직, 5.퇴직 <br/>
        /// id_name 키워드 검색(아이디 or 이름)  <br/>
        /// memo 메모 검색
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(int mCode, string level, string working, string id_name, string memo, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;
            string TotalCount = string.Empty;

            List<UserList> users = new List<UserList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.GET_USERS_LIST",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mCode;
            cmd.Parameters.Add("in_user_level", OracleDbType.Varchar2, 1).Value = level;
            cmd.Parameters.Add("in_working", OracleDbType.Varchar2, 1).Value = working;
            cmd.Parameters.Add("in_user_id_name", OracleDbType.Varchar2, 30).Value = id_name;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 100).Value = memo;
            cmd.Parameters.Add("in_page", OracleDbType.Int32).Value = page;
            cmd.Parameters.Add("in_rows", OracleDbType.Int32).Value = rows;
            cmd.Parameters.Add("out_total_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_count", OracleDbType.Varchar2, 10).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                TotalCount = cmd.Parameters["out_total_count"].Value.ToString();
                Rcount = cmd.Parameters["out_count"].Value.ToString();
                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    UserList m = new UserList
                    {
                        ccCode = rd["CCCODE"].ToString(),
                        uCode = rd["UCODE"].ToString(),
                        id = rd["USER_ID"].ToString(),
                        name = rd["USER_NAME"].ToString(),
                        insertDate = rd["ISRT_DT"].ToString(),
                        retireDate = rd["RETIRE_DT"].ToString(),
                        level = rd["USER_LEVEL"].ToString(),
                        memo = rd["MEMO"].ToString(),
                        working = rd["WORKING"].ToString(),
                    };

                    users.Add(m);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, total_count = TotalCount, count = Rcount, data = users });
        }


        [HttpPost]
        public async Task<IActionResult> Post(User user)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.ADD_USER",
            };

            cmd.Parameters.Add("in_cccode", OracleDbType.Varchar2, 10).Value = user.ccCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 30).Value = user.name;
            cmd.Parameters.Add("in_user_id", OracleDbType.Varchar2, 20).Value = user.id;
            cmd.Parameters.Add("in_user_pass", OracleDbType.Varchar2, 20).Value = user.password;
            cmd.Parameters.Add("in_user_level", OracleDbType.Char, 1).Value = user.level;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = user.mobile;
            cmd.Parameters.Add("in_working", OracleDbType.Char, 1).Value = user.working;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 1000).Value = user.memo;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = user.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = user.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpPut]
        public async Task<IActionResult> Put(User user)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);
            OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.UPDATE_USER",
            };

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = user.uCode;
            cmd.Parameters.Add("in_user_name", OracleDbType.Varchar2, 30).Value = user.name;
            cmd.Parameters.Add("in_user_id", OracleDbType.Varchar2, 20).Value = user.id;
            cmd.Parameters.Add("in_user_pass", OracleDbType.Varchar2, 20).Value = user.password;
            cmd.Parameters.Add("in_user_level", OracleDbType.Char, 1).Value = user.level;
            cmd.Parameters.Add("in_mobile", OracleDbType.Varchar2, 20).Value = user.mobile;
            cmd.Parameters.Add("in_working", OracleDbType.Char, 1).Value = user.working;
            cmd.Parameters.Add("in_memo", OracleDbType.Varchar2, 1000).Value = user.memo;
            cmd.Parameters.Add("in_mod_ucode", OracleDbType.Int32).Value = user.modUCode;
            cmd.Parameters.Add("in_mod_name", OracleDbType.Varchar2, 50).Value = user.modName;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// 사용자 관리 - 목록 상세 조회
        /// </summary>
        /// <remarks>
        /// ucode 조회대상 ucode<br/>
        /// rUcode 조회자 ucode(개인정보 조회기록을 남기는 용도)
        /// </remarks>
        [HttpGet("{ucode}")]
        public async Task<IActionResult> Get(string ucode, string rUcode)
        {
            string Rposition = "/User/{ucode} : Get";
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.GET_USER_DETAIL",
            };

            cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            User user = new User();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                user.uCode = rd["UCODE"].ToString();
                user.ccCode = rd["CCCODE"].ToString();
                user.id = rd["USER_ID"].ToString();
                user.name = rd["USER_NAME"].ToString();
                user.insertDate = rd["ISRT_DT"].ToString();
                user.retireDate = rd["RETIRE_DT"].ToString();
                user.level = rd["USER_LEVEL"].ToString();
                user.mobile = rd["MOBILE"].ToString();
                user.memo = rd["MEMO"].ToString();
                user.working = rd["WORKING"].ToString();

                await rd.CloseAsync();
                await conn.CloseAsync();

                //조회 로그 기록
                await Utils.setPrivacyLog(rUcode, "2", "10", user.name + " - 이름, 전화번호, 비밀번호", Rposition);


            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync(Rposition, ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = user });
        }

        /// <summary>
        /// 사용자정보 변경이력
        /// </summary>
        /// <remarks>
        /// page와 rows값이 필요하지만 현재 페이징처리를 하고있지는 않음 <br/>
        /// ex) page = 1, rows = 10000
        /// </remarks>
        [HttpGet("getUserHist/{ucode}")]
        public async Task<IActionResult> history(string ucode, int page, int rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RCount = string.Empty;
            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("ucode", ucode);
                param.Add("in_page", page);
                param.Add("in_rows", rows);

                string sql = @" SELECT *
                                FROM (select ROWNUM as NO, T1.*
                                from(select * from users_hist
                                            where ucode = :ucode
                                            order by hist_date desc) T1
                                WHERE ROWNUM <= (:in_page * :in_rows)) T2
                                WHERE ((:in_page - 1) * :in_rows) < NO
                ";

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @" select count(*) from users_hist
                         where ucode = :ucode
                ";

                RCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount, data = items });
        }


        [HttpGet("logIn/{id}/{password}")]
        public async Task<IActionResult> logIn(string id, string password)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.USER_LOGIN_V2",
            };

            cmd.Parameters.Add("in_user_id", OracleDbType.Varchar2, 20).Value = id;
            cmd.Parameters.Add("in_user_password", OracleDbType.Varchar2, 100).Value = password;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            User user = new User();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await rd.ReadAsync();

                if (Rcode.Equals("00"))
                {
                    user.uCode = rd["UCODE"].ToString();
                    user.id = rd["USER_ID"].ToString();
                    user.name = rd["USER_NAME"].ToString();
                    user.insertDate = rd["ISRT_DT"].ToString();
                    user.retireDate = rd["RETIRE_DT"].ToString();
                    user.level = rd["USER_LEVEL"].ToString();
                    user.memo = rd["MEMO"].ToString();
                    user.working = rd["WORKING"].ToString();
                }

                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/logIn/{id}/{password} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = user });
        }


        //[HttpGet("otpConfirm/{ucode}/{security_code}")]
        //public async Task<IActionResult> otpConfirm(string ucode, string security_code)
        //{
        //    string Rcode = string.Empty;
        //    string Rmsg = string.Empty;

        //    using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

        //    using OracleCommand cmd = new OracleCommand
        //    {
        //        Connection = conn,
        //        CommandType = CommandType.StoredProcedure,
        //        CommandText = "PKG_IS_ADMIN_USER.CONFIRM_OTP",
        //    };

        //    cmd.Parameters.Add("in_ucode", OracleDbType.Int32).Value = ucode;
        //    cmd.Parameters.Add("in_security_code", OracleDbType.Varchar2, 100).Value = security_code;
        //    cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
        //    cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

        //    try
        //    {
        //        await conn.OpenAsync();
        //        var rd = await cmd.ExecuteReaderAsync();

        //        Rcode = cmd.Parameters["out_code"].Value.ToString();
        //        Rmsg = cmd.Parameters["out_msg"].Value.ToString();

        //        await rd.CloseAsync();
        //        await conn.CloseAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        await Utils.SaveErrorAsync("/User/otpConfirm/{ucode}/{security_code} : Get", ex.Message);
        //    }

        //    return Ok(new { code = Rcode, msg = Rmsg });
        //}

        [HttpGet("idCheck/{id}")]
        public async Task<IActionResult> idCheck(string id)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.USER_ID_CHECK",
            };

            cmd.Parameters.Add("in_user_id", OracleDbType.Varchar2, 20).Value = id;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            User user = new User();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/idCheck/{id} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        /// <summary>
        /// [미사용] 사용자 목록 조회 (getNameList로 대체)
        /// </summary>
        [HttpGet("user_code_name")]
        public async Task<IActionResult> userCodeName(string mcode, string level)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_ADMIN_USER.USER_CODE_NAME",
            };

            cmd.Parameters.Add("in_mcode", OracleDbType.Int32).Value = mcode;
            cmd.Parameters.Add("in_user_level", OracleDbType.Varchar2, 1).Value = level;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<CodeName> items = new List<CodeName>();
            

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();


                while (await rd.ReadAsync())
                {
                    CodeName item = new CodeName
                    {
                        code = rd["UCODE"].ToString(),
                        name = rd["USER_NAME"].ToString()
                    };

                    items.Add(item);
                };

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/userCodeName : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        [HttpPost("addLoginLog")]
        public async Task<IActionResult> addLoginLog(int ucode, string log_gbn, string ip, string mac, string memo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();
            DynamicParameters param = new DynamicParameters();
            param.Add("ucode", ucode);
            param.Add("log_gbn", log_gbn);
            param.Add("ip", ip);
            param.Add("mac", mac);
            param.Add("memo", memo);

            try
            {
                await db.ExecuteAsync("INSERT INTO ADMIN_LOGIN_LOG(UCODE, LOG_GBN, IP, MAC, MEMO, LOG_TIME) VALUES (:ucode, :log_gbn, :ip, :mac, :memo, SYSDATE)", param);

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/addLoginLog : Post", ex.Message);
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //마스킹 해제 로그 삽입
        [HttpPost("addAppReadLog")]
        public async Task<IActionResult> addAppReadLog(int ucode, string uname, string part_id)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
            db.Open();
            DynamicParameters param = new DynamicParameters();
            param.Add("ucode", ucode);
            param.Add("uname", uname);
            param.Add("part_id", part_id);


            try
            {
                await db.ExecuteAsync("INSERT INTO USER_APP_READ_LOG(UCODE, UNAME, PART_ID, INSERT_DATE) VALUES (:ucode, :uname, :part_id, SYSDATE)", param);

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/addAppReadLog : Post", ex.Message);
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        //마스킹 해제 로그 조회
        [HttpGet("getAppReadLog")]
        public async Task<IActionResult> getAppReadLog(string date_begin, string date_end, string uname, string part_id, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string Rcount = string.Empty;

            List<object> items = new List<object>();


            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("uname", uname);
                param.Add("part_id", part_id);
                param.Add("page", page);
                param.Add("row_count", rows);
                string unameSql = string.Empty;
                string partIdSql = string.Empty;
                if (uname is not null)
                {
                    unameSql = @"AND A.UNAME = :uname";
                }

                if (part_id is not null)
                {
                    partIdSql = @"AND A.PART_ID = : part_id";
                }

                string sql = @$"
                                select count(*) from USER_APP_READ_LOG A, ETC_CODE B
                                            WHERE  A.PART_ID = B.CODE (+)
                                                AND to_char(A.INSERT_DATE, 'YYYYMMDD') between :date_begin and :date_end
                                                {unameSql}
                                                {partIdSql}
                                ";

                Rcount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @$"
                                SELECT t2.*
                                FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                      FROM (select A.*, B.CODE_NM from USER_APP_READ_LOG A, ETC_CODE B
                                            WHERE  A.PART_ID = B.CODE (+)
                                                AND to_char(A.INSERT_DATE, 'YYYYMMDD') between :date_begin and :date_end
                                                {unameSql}
                                                {partIdSql}
                                            ORDER BY A.seq) t1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                WHERE (( :page - 1) * :row_count) < RNUM
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/getAppReadLog : Get", ex.Message);
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = Rcount, data = items });
        }

        //사용자명 조회
        [HttpGet("getUserName")]
        public static async Task<string> getUserName(string ucode)
        {
            string result = string.Empty;
            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("ucode", ucode);
                
                string sql = @$"
                                select user_name from users where ucode = :ucode
                                ";

                result = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/User/getUserName : Get", ex.Message);
            }

            return result;
        }


    }
}
