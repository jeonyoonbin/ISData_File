﻿using Dapper;
using DG_App_Rest.Areas.Admin.Models;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class ChainCouponController : ControllerBase
    {

        /// <summary>
        /// 브랜드 목록 조회
        /// </summary>
        [HttpGet("getChainList")]
        public async Task<IActionResult> getChainList()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            string sql = @$"
                            select code, code_nm from etc_code
                            where code_grp = 'API'
                            and pgm_group = 'O'
                            and use_gbn = 'Y'
                            order by code_nm
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 브랜드별 쿠폰목록 조회
        /// </summary>
        [HttpGet("getChainCouponList")]
        public async Task<IActionResult> getChainCouponList(string chainCode)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();

            using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

            DynamicParameters param = new DynamicParameters();
            param.Add("in_chain_code", chainCode);

            string sql = @$"
                            select code, code_nm 
                            from etc_code 
                            where code_grp = 'BRAND_COUPON' 
                            AND use_gbn = 'Y'
                            and etc_code1 like case when :in_chain_code is null then '%' else :in_chain_code end
                            order by ins_date desc
                        ";

            try
            {
                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 브랜드쿠폰명 검색
        /// </summary>
        /// <remarks>
        /// test_yn 테스트여부(Y/N)(필수) <br/>
        /// [response] <br/>
        /// code 코드 <br/>
        /// name 브랜드쿠폰명 <br/>
        /// use_gbn 사용여부 <br/>
        /// </remarks>
        [HttpGet("getNameList")]
        public async Task<IActionResult> getNameList(string test_yn, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<ChainName> items = new List<ChainName>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.GET_COUPON_NAME_LIST",
            };

            cmd.Parameters.Add("in_test_yn", OracleDbType.Varchar2, 1).Value = test_yn;
            cmd.Parameters.Add("in_keyword", OracleDbType.Varchar2, 50).Value = keyword;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    ChainName item = new ChainName
                    {
                        code = rd["code"].ToString(),
                        name = rd["code_nm"].ToString(),
                        use_gbn = rd["use_gbn"].ToString(),
                    };

                    items.Add(item);
                }

                await rd.CloseAsync();
                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCoupon/getNameList : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 브랜드 쿠폰 관리 - 목록 조회
        /// </summary>
        /// <remarks>
        /// div 구분 (1. 쿠폰번호, 2. 가맹점명) <br />
        /// return data <br />
        /// pub: 발행/ giv: 고객발급/ use: 사용/ exp: 만료/ del: 폐기 <br />
        /// </remarks>
        [HttpGet]
        public async Task<IActionResult> Get(string chainCode, string couponType, string status, string div, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            object RCount = string.Empty;

            string Rpub = string.Empty;
            string Rgiv = string.Empty;
            string Ruse = string.Empty;
            string Rexp = string.Empty;
            string Rdel = string.Empty;


            List<object> items = new List<object>();

            CouponCount count = new CouponCount();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_chain_code", chainCode);
                param.Add("in_coupon_type", couponType);
                param.Add("in_coupon_status", status);
                param.Add("in_div", div);
                param.Add("in_keyword", keyword);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = string.Empty;
                
                if(string.IsNullOrEmpty(div) || div == "1")
                {
                    sql = $@"
                                   SELECT  /*+ use_nl(B) use_nl(C) no_merge(E) push_pred(E) */ nvl(to_char(T2.app_cust_code),' ') app_cust_code,
                                           t2.BARCODE,
                                           t2.conf_date,
                                           t2.conf_name,
                                           t2.conf_yn,
                                           t2.coupon_amt,
                                           t2.coupon_name,
                                           t2.coupon_no,
                                           t2.coupon_type,
                                           Nvl(B.CUST_NAME,' ') CUST_NAME,
                                           t2.exp_date,
                                           t2.ins_date,
                                           t2.ins_name,
                                           t2.ins_ucode,
                                           t2.link_url,
                                           t2.order_date,
                                           Nvl(TO_CHAR(T2.ORDER_NO),' ') ORDER_NO,
                                           t2.random_no,
                                           t2.rnum,
                                           Nvl(D.SHOP_CD,' ') SHOP_CD,
                                           Nvl(D.SHOP_NAME,' ') SHOP_NAME,
                                           D.service_gbn,
                                           t2.status,
                                           t2.st_date,
                                           Nvl(B.TELNO,' ')     TELNO,
                                           t2.use_app_cust_code,
                                           Nvl(C.CUST_NAME,' ') AS USE_CUST_NAME,
                                           t2.use_date,
                                           Nvl(C.TELNO,' ')     AS USE_TELNO
                                    FROM   (SELECT To_char(ROWNUM) AS RNUM,
                                                   T1.*
                                            FROM   (SELECT   A.COUPON_TYPE,
                                                             A.COUPON_NAME,
                                                             A.COUPON_NO,
                                                             Nvl(A.RANDOM_NO,' ')                                    RANDOM_NO,
                                                             Nvl(A.BARCODE,' ')                                      BARCODE,
                                                             A.STATUS, 
                                    -- nvl(A.APP_SHOP_CODE,' ') APP_SHOP_CODE,
                                                             A.APP_CUST_CODE                       APP_CUST_CODE,
                                                             Nvl(To_char(A.USE_APP_CUST_CODE),' ')                   USE_APP_CUST_CODE,
                                                             Nvl(A.ORDER_DATE,' ')                                   ORDER_DATE,
                                                             A.ORDER_NO                          ORDER_NO,
                                                             Nvl(To_char (A.USE_DATE, 'YYYY-MM-DD HH24:MI:SS'),' ')  AS USE_DATE,
                                                             To_char(A.COUPON_AMT)                                   COUPON_AMT,
                                                             Nvl(A.LINK_URL,' ')                                     LINK_URL,
                                                             Nvl(A.INS_DATE,' ')                                     AS INS_DATE,
                                                             To_char(A.INS_UCODE)                                    INS_UCODE,
                                                             A.INS_NAME,
                                                             Nvl(A.EXP_DATE,' ')                                     AS EXP_DATE,
                                                             CASE
                                                               WHEN A.PUBLISH_DATE IS NULL
                                                               THEN Nvl(A.ST_DATE,' ')
                                                               ELSE To_char(A.PUBLISH_DATE,'YYYYMMDD')
                                                             END                                                     ST_DATE,
                                                             A.CONF_YN,
                                                             Nvl(To_char (A.CONF_DATE, 'YYYY-MM-DD HH24:MI:SS'),' ') AS CONF_DATE,
                                                             Nvl(To_char(A.CONF_UCODE),' ')                          CONF_UCODE,
                                                             Nvl(A.CONF_NAME,' ')                                    CONF_NAME
                                                    FROM     IS_DAEGU.CHAIN_COUPON_MST A
                                                    WHERE    A.CHAIN_CODE LIKE CASE
                                                                                 WHEN :in_chain_code IS NOT NULL
                                                                                 THEN :in_chain_code
                                                                                 ELSE '%'
                                                                               END
                                                         AND A.COUPON_TYPE LIKE CASE
                                                                                  WHEN :in_coupon_type IS NOT NULL
                                                                                  THEN :in_coupon_type
                                                                                  ELSE '%'
                                                                                END
                                                         AND A.STATUS = :in_coupon_status
                                                         AND ( :in_keyword IS NULL
                                                            OR ( A.COUPON_NO LIKE '%' 
                                                                                    || :in_keyword 
                                                                                    || '%' ) )
                                                    ORDER BY A.COUPON_TYPE,
                                                             A.COUPON_NO) T1
                                            WHERE  ROWNUM <= ( ( :page - 1 ) * :row_count ) + :row_count) T2,
                                           IS_DAEGU.APP_CUSTOMER B,
                                           IS_DAEGU.APP_CUSTOMER C,
                                           IS_DAEGU.SHOP_INFO D,
                                           (SELECT order_no,
                                                   shop_cd
                                            FROM   IS_DAEGU.dorder
                                            UNION ALL
                                            SELECT order_no,
                                                   shop_cd
                                            FROM   IS_DAEGU.dorder_past) E
                                    WHERE  ( ( :page - 1 ) * :row_count ) < RNUM
                                       AND T2.APP_CUST_CODE = B.CUST_CODE (+)
                                       AND T2.APP_CUST_CODE = C.CUST_CODE (+)
                                       AND T2.ORDER_NO = E.ORDER_NO (+)
                                       AND E.SHOP_CD = D.SHOP_CD (+) 
                                ";
                }
                else if(div == "2")
                {
                    sql = $@" SELECT  /*+ use_nl(B) use_nl(C) */ nvl(to_char(T2.app_cust_code),' ') app_cust_code,
                                           t2.BARCODE,
                                           t2.conf_date,
                                           t2.conf_name,
                                           t2.conf_yn,
                                           t2.coupon_amt,
                                           t2.coupon_name,
                                           t2.coupon_no,
                                           t2.coupon_type,
                                           Nvl(B.CUST_NAME,' ') CUST_NAME,
                                           t2.exp_date,
                                           t2.ins_date,
                                           t2.ins_name,
                                           t2.ins_ucode,
                                           t2.link_url,
                                           t2.order_date,
                                           Nvl(TO_CHAR(T2.ORDER_NO),' ') ORDER_NO,
                                           t2.random_no,
                                           t2.rnum,
                                           t2.SHOP_CD,
                                           t2.SHOP_NAME,
                                           t2.service_gbn,
                                           t2.status,
                                           t2.st_date,
                                           Nvl(B.TELNO,' ')     TELNO,
                                           t2.use_app_cust_code,
                                           Nvl(C.CUST_NAME,' ') AS USE_CUST_NAME,
                                           t2.use_date,
                                           Nvl(C.TELNO,' ')     AS USE_TELNO
                                    FROM   (SELECT To_char(ROWNUM) AS RNUM,
                                                   T1.*
                                            FROM   (SELECT   A.COUPON_TYPE,
                                                             A.COUPON_NAME,
                                                             A.COUPON_NO,
                                                             Nvl(A.RANDOM_NO,' ')                                    RANDOM_NO,
                                                             Nvl(A.BARCODE,' ')                                      BARCODE,
                                                             A.STATUS, 
                                                             A.APP_CUST_CODE                       APP_CUST_CODE,
                                                             Nvl(To_char(A.USE_APP_CUST_CODE),' ')                   USE_APP_CUST_CODE,
                                                             Nvl(A.ORDER_DATE,' ')                                   ORDER_DATE,
                                                             A.ORDER_NO                          ORDER_NO,
                                                             Nvl(To_char (A.USE_DATE, 'YYYY-MM-DD HH24:MI:SS'),' ')  AS USE_DATE,
                                                             To_char(A.COUPON_AMT)                                   COUPON_AMT,
                                                             Nvl(A.LINK_URL,' ')                                     LINK_URL,
                                                             Nvl(A.INS_DATE,' ')                                     AS INS_DATE,
                                                             To_char(A.INS_UCODE)                                    INS_UCODE,
                                                             A.INS_NAME,
                                                             Nvl(A.EXP_DATE,' ')                                     AS EXP_DATE,
                                                             CASE
                                                               WHEN A.PUBLISH_DATE IS NULL
                                                               THEN Nvl(A.ST_DATE,' ')
                                                               ELSE To_char(A.PUBLISH_DATE,'YYYYMMDD')
                                                             END                                                     ST_DATE,
                                                             A.CONF_YN,
                                                             Nvl(To_char (A.CONF_DATE, 'YYYY-MM-DD HH24:MI:SS'),' ') AS CONF_DATE,
                                                             Nvl(To_char(A.CONF_UCODE),' ')                          CONF_UCODE,
                                                             Nvl(A.CONF_NAME,' ')                                    CONF_NAME,
                                                             b.shop_cd,
                                                             b.shop_name,
                                                             b.service_gbn
                                       from IS_DAEGU.CHAIN_COUPON_MST A,
                                           (select b.coupon_no2, a.shop_cd, a.shop_name, a.service_gbn
                                           from shop_info a, 
                                                (SELECT order_no,
                                                       shop_cd,
                                                       cccode,
                                                       coupon_no2
                                                FROM   IS_DAEGU.dorder
                                                UNION ALL
                                                SELECT order_no,
                                                       shop_cd,
                                                       cccode,
                                                       coupon_no2
                                                FROM   IS_DAEGU.dorder_past) b
                                           where a.shop_cd = b.shop_cd
                                           and a.cccode = b.cccode
                                           and shop_name like '%' || :in_keyword || '%')B
                                       where a.coupon_no = b.coupon_no2
                                       and A.CHAIN_CODE LIKE CASE
                                                                WHEN :in_chain_code IS NOT NULL
                                                                THEN :in_chain_code
                                                                ELSE '%'
                                                            END
                                         AND A.COUPON_TYPE LIKE CASE
                                                                  WHEN :in_coupon_type IS NOT NULL
                                                                  THEN :in_coupon_type
                                                                  ELSE '%'
                                                                END
                                         AND A.STATUS = :in_coupon_status
                                         ORDER BY A.COUPON_TYPE,
                                                             A.use_date desc) T1
                                            WHERE  ROWNUM <= ( ( :page - 1 ) * :row_count ) + :row_count) T2,
                                           IS_DAEGU.APP_CUSTOMER B,
                                           IS_DAEGU.APP_CUSTOMER C
                                    WHERE  ( ( :page - 1 ) * :row_count ) < RNUM
                                       AND T2.APP_CUST_CODE = B.CUST_CODE (+)
                                       AND T2.APP_CUST_CODE = C.CUST_CODE (+)
                                       ";
                }
                

                db.Open();

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                string countSql = string.Empty;
                if (string.IsNullOrEmpty(div) || div == "1")
                {
                    countSql = $@"
                                    SELECT COUNT(*)
                                    FROM CHAIN_COUPON_MST  A
                                    WHERE    A.CHAIN_CODE LIKE case when :in_chain_code is not null then :in_chain_code else '%' end
                                         AND A.COUPON_TYPE LIKE case when :in_coupon_type is not null then :in_coupon_type else '%' end
                                         AND A.STATUS LIKE case when :in_coupon_status is not null then :in_coupon_status else '%' end
                                         AND (:in_keyword IS NULL OR (A.COUPON_NO LIKE '%' || :in_keyword || '%'))
                                ";
                }
                else if(div == "2")
                {
                    countSql = $@"
                                    select count(*)
                                        from IS_DAEGU.CHAIN_COUPON_MST A,
                                           (select b.coupon_no2, a.shop_cd, a.shop_name, a.service_gbn
                                           from shop_info a, 
                                                (SELECT order_no,
                                                       shop_cd,
                                                       cccode,
                                                       coupon_no2
                                                FROM   IS_DAEGU.dorder
                                                UNION ALL
                                                SELECT order_no,
                                                       shop_cd,
                                                       cccode,
                                                       coupon_no2
                                                FROM   IS_DAEGU.dorder_past) b
                                           where a.shop_cd = b.shop_cd
                                           and a.cccode = b.cccode
                                           and shop_name like '%' || :in_keyword || '%')B
                                       where a.coupon_no = b.coupon_no2
                                       and A.CHAIN_CODE LIKE CASE
                                                                  WHEN :in_chain_code IS NOT NULL
                                                                  THEN :in_chain_code
                                                                  ELSE '%'
                                                                END
                                         AND A.COUPON_TYPE LIKE CASE
                                                                  WHEN :in_coupon_type IS NOT NULL
                                                                  THEN :in_coupon_type
                                                                  ELSE '%'
                                                                END
                                         AND A.STATUS = :in_coupon_status
                                ";
                }

                RCount = await db.ExecuteScalarAsync<Int64>(countSql, param, commandType: CommandType.Text);

                var count2Sql = $@"
                                    SELECT to_char(count(case when conf_yn = 'Y'  then 1 end)) as pub,
                                         to_char(count(case when app_cust_code is not null and status <> '99' then 1 end)) as giv,
                                         to_char(count(case when status = '30' then 1 end)) as use,
                                         to_char(count(case when status = '40' then 1 end)) as exp,
                                         to_char(count(case when status = '99' then 1 end)) as del
                                    FROM CHAIN_COUPON_MST
                                   WHERE CHAIN_CODE LIKE case when :in_chain_code is not null then :in_chain_code else '%' end
                                   AND COUPON_TYPE LIKE case when :in_coupon_type is null then '%' else :in_coupon_type end
                                ";

                count = await db.QuerySingleAsync<CouponCount>(count2Sql, param, commandType: CommandType.Text);


                Rpub = count.pub;
                Rgiv = count.giv;
                Ruse = count.use;
                Rexp = count.exp;
                Rdel = count.del;

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCoupon : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = RCount.ToString(), pub = Rpub, giv = Rgiv, use = Ruse, exp = Rexp, del = Rdel, data = items });
        }


        /// <summary>
        /// 브랜드쿠폰 상세조회
        /// </summary>
        [HttpGet("{couponNo}")]
        public async Task<IActionResult> getDetail(string couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            object RtotalCount = string.Empty;
            object RCount = string.Empty;


            object item = string.Empty;

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();
                param.Add("in_coupon_no", couponNo);


                string sql = $@" SELECT A.COUPON_TYPE,
                                        A.COUPON_NAME,
                                        A.COUPON_NO,
                                        nvl(A.RANDOM_NO,' ') RANDOM_NO,
                                        nvl(A.BARCODE,' ') BARCODE,
                                        A.STATUS,
                                        nvl(A.APP_SHOP_CODE,' ') APP_SHOP_CODE,
                                        nvl(D.SHOP_NAME,' ') SHOP_NAME,
                                        nvl(to_char(A.APP_CUST_CODE),' ')  APP_CUST_CODE,
                                        nvl(B.CUST_NAME,' ') CUST_NAME,
                                        nvl(B.TELNO,' ') TELNO,
                                        nvl(to_char(A.USE_APP_CUST_CODE),' ') USE_APP_CUST_CODE,
                                        nvl(C.CUST_NAME,' ') 
                                            AS USE_CUST_NAME,
                                        nvl(C.TELNO,' ') 
                                            AS USE_TELNO,
                                        nvl(A.ORDER_DATE,' ') ORDER_DATE,
                                        nvl(TO_CHAR (A.ORDER_NO),' ') ORDER_NO,
                                        nvl(TO_CHAR (A.USE_DATE,
                                                'YYYY-MM-DD HH24:MI:SS'),' ')
                                            AS USE_DATE,
                                        to_char(A.COUPON_AMT) COUPON_AMT,
                                        to_char(A.ISD_AMT) ISD_AMT,
                                        to_char(A.OTHER_AMT) OTHER_AMT,
                                        nvl(A.LINK_URL,' ') LINK_URL,
                                        A.INS_DATE,
                                        to_char(A.INS_UCODE) INS_UCODE,
                                        A.INS_NAME,
                                        A.EXP_DATE,
                                        A.ST_DATE,
                                        A.CONF_YN,
                                        nvl(TO_CHAR (A.CONF_DATE,
                                                'YYYY-MM-DD HH24:MI:SS'),' ')
                                            AS CONF_DATE,
                                        nvl(to_char(A.CONF_UCODE),' ') CONF_UCODE,
                                        nvl(A.CONF_NAME,' ') CONF_NAME,
                                        nvl(to_char(a.mod_ucode),' ') mod_ucode,
                                        nvl(a.mod_name,' ') mod_name,
                                        nvl(TO_CHAR (a.mod_date,
                                                'YYYY-MM-DD HH24:MI:SS'),' ')
                                            AS mod_date,
                                        nvl(to_char(a.sms_send_cnt),' ') sms_send_cnt,
                                        nvl(TO_CHAR (a.sms_send_date,
                                                'YYYY-MM-DD HH24:MI:SS'),' ')
                                            AS sms_send_date,
                                        nvl(to_char(a.push_send_cnt),' ') push_send_cnt,
                                        nvl(TO_CHAR (a.push_send_date,
                                                'YYYY-MM-DD HH24:MI:SS'),' ')
                                            AS push_send_date,
                                        nvl(E.MEMO,' ') memo
                                FROM CHAIN_COUPON_MST  A,
                                        APP_CUSTOMER B,
                                        APP_CUSTOMER C,
                                        SHOP_INFO D,
                                        etc_code e
                                WHERE     A.APP_CUST_CODE = B.CUST_CODE(+)
                                        AND A.USE_APP_CUST_CODE = C.CUST_CODE(+)
                                        AND A.APP_SHOP_CODE = D.SHOP_CD(+)
                                        and a.coupon_type = e.code (+)
                                        and e.code_grp = 'BRAND_COUPON'
                                        AND A.COUPON_NO = :in_coupon_no
                                ";

                db.Open();

                item = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCoupon/{couponNo} : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = item });
        }



        //프렌차이즈 쿠폰 발행
        [HttpPost]
        public async Task<IActionResult> Post(string couponType, string couponCount, string chainCode, string startDate, string endDate, string isdAmt, string insertUcode, string insertName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.SET_COUPON_MST",
            };

            //cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = "1";
            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_chain_code", OracleDbType.Varchar2, 10).Value = chainCode;
            cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = int.Parse(couponCount);
            cmd.Parameters.Add("in_st_date", OracleDbType.Varchar2, 10).Value = startDate;
            cmd.Parameters.Add("in_exp_date", OracleDbType.Varchar2, 10).Value = endDate;
            //cmd.Parameters.Add("in_display_st_date", OracleDbType.Varchar2, 10).Value = startDate; 
            //cmd.Parameters.Add("in_display_exp_date", OracleDbType.Varchar2, 10).Value = startDate;  
            cmd.Parameters.Add("in_isd_amt", OracleDbType.Int32).Value = int.Parse(isdAmt);
            //cmd.Parameters.Add("in_other_amt", OracleDbType.Int32).Value = isdAmt;
            cmd.Parameters.Add("in_ins_ucode", OracleDbType.Int32).Value = int.Parse(insertUcode);
            cmd.Parameters.Add("in_ins_name", OracleDbType.Varchar2, 50).Value = insertName;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCoupon : Post", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        //프렌차이즈 쿠폰 일괄 상태변경(승인)
        [HttpPut]
        public async Task<IActionResult> Put(string couponType, string couponCount, string oldStatus, string newStatus, string jobUcode, string jobName)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            IEnumerable<string> couponNo  = new[]{""};

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.SET_COUPON_MST_STATUS",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 10).Value = "1";
            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_coupon_cnt", OracleDbType.Int32).Value = int.Parse(couponCount);
            cmd.Parameters.Add("in_old_status", OracleDbType.Varchar2, 10).Value = oldStatus;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 10).Value = newStatus;

            var arrCouponNo = cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50);
            arrCouponNo.Direction = ParameterDirection.Input;
            arrCouponNo.CollectionType = OracleCollectionType.PLSQLAssociativeArray;
            arrCouponNo.Value = couponNo.ToArray();
            arrCouponNo.Size = couponNo.Count();
            arrCouponNo.ArrayBindSize = couponNo.Select(_ => _.Length).ToArray();
            arrCouponNo.ArrayBindStatus = Enumerable.Repeat(OracleParameterStatus.Success, couponNo.Count()).ToArray();

            cmd.Parameters.Add("in_job_ucode", OracleDbType.Int32).Value = int.Parse(jobUcode);
            cmd.Parameters.Add("in_job_name", OracleDbType.Varchar2, 50).Value = jobName;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCoupon : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }


        [HttpGet("history/{couponNo}")]
        public async Task<IActionResult> GetHistory(string couponNo)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.GET_COUPON_HISTORY",
            };

            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 50).Value = couponNo;
            cmd.Parameters.Add("out_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

            List<CouponHistory> couponHistories = new List<CouponHistory>();

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();

                Rcode = cmd.Parameters["out_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_msg"].Value.ToString();

                while (await rd.ReadAsync())
                {
                    CouponHistory couponHistory = new CouponHistory
                    {
                        SeqNo = rd["SEQNO"].ToString(),
                        couponType = rd["COUPON_TYPE"].ToString(),
                        couponNo = rd["COUPON_NO"].ToString(),
                        histDate = rd["HIST_DATE"].ToString(),
                        memo = rd["MEMO"].ToString(),
                    };

                    couponHistories.Add(couponHistory);
                }
                await rd.CloseAsync();
                await conn.CloseAsync();

            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCoupon/history/couponNo : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = couponHistories });
        }


        //고객 쿠폰 발행(고객용 앱에서 처리), 2021/03/20
        //전체 상태(00:대기, 10:승인, 20:발행(고객), 30:사용(고객), 99:폐기)
        //고객 상태(in_status( 20:고객 발행, 30:'사용, 50:주문취소, 60:발행상태 취소) 
        [HttpPut("setCouponAppCustomer2")]
        public async Task<IActionResult> setCouponAppCustomer2(string custCode, string couponType, string couponNo, string status)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RcouponNo = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.SET_COUPON_APP_CUSTOMER",
            };

            cmd.Parameters.Add("in_job_gbn", OracleDbType.Varchar2, 1).Value = "3";  // 1: 쿠폰타입으로 등록, 3 : 쿠폰번호로 등록
            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = custCode;
            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 1000).Value = couponNo;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 2).Value = status;
            cmd.Parameters.Add("in_order_no", OracleDbType.Int32).Value = null;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_coupon", OracleDbType.Varchar2, 100).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("in_shop_cd", OracleDbType.Varchar2, 10).Value = null;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["OUT_RET_CODE"].Value.ToString();
                if (Rcode.Equals("00"))
                {
                    Rmsg = "성공";
                }
                else
                {
                    Rmsg = cmd.Parameters["OUT_RET_MSG"].Value.ToString();
                }

                RcouponNo = cmd.Parameters["OUT_RET_COUPON"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCoupon/setCouponAppCustomer2 : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, couponNo = RcouponNo });
        }


        //전체 상태(00:대기, 10:승인, 20:발행(고객), 30:사용(고객), 99:폐기)
        //변경가능 상태(in_status( 10, 99) )
        [HttpPut("setCouponAppCustomer")]
        public async Task<IActionResult> setCouponAppCustomer(string modUcode, string custCode, string couponType, string couponNo, string status)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<CouponList> coupons = new List<CouponList>();

            using OracleConnection conn = new OracleConnection(Utils.oracleConnectString);

            using OracleCommand cmd = new OracleCommand
            {
                Connection = conn,
                CommandType = CommandType.StoredProcedure,
                CommandText = "PKG_IS_CHAIN_COUPON_MNG.SET_COUPON_MST_STATUS2",
            };

            cmd.Parameters.Add("in_coupon_type", OracleDbType.Varchar2, 10).Value = couponType;
            cmd.Parameters.Add("in_new_status", OracleDbType.Varchar2, 10).Value = status;
            cmd.Parameters.Add("in_cust_code", OracleDbType.Int32).Value = int.Parse((custCode is null) ? "0": custCode );
            cmd.Parameters.Add("in_coupon_no", OracleDbType.Varchar2, 100).Value = couponNo;
            cmd.Parameters.Add("in_job_ucode", OracleDbType.Int32).Value = int.Parse(modUcode);
            cmd.Parameters.Add("in_job_name", OracleDbType.Varchar2, 50).Value = null;
            cmd.Parameters.Add("out_ret_code", OracleDbType.Varchar2, 2).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("out_ret_msg", OracleDbType.Varchar2, 1000).Direction = ParameterDirection.Output;

            try
            {
                await conn.OpenAsync();
                var rd = await cmd.ExecuteReaderAsync();
                Rcode = cmd.Parameters["out_ret_code"].Value.ToString();
                Rmsg = cmd.Parameters["out_ret_msg"].Value.ToString();

                await conn.CloseAsync();
            }
            catch (Exception ex)
            {
                await Utils.SaveErrorAsync("/ChainCoupon/setCouponAppCustomer : Put", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

        // 쿠폰 발행/사용 현황
        [HttpGet("getCouponHistory")]
        public async Task<IActionResult> getCouponHistory(string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                SELECT t2.status,
                                   t2.coupon_name,
                                   t2.coupon_no,
                                   t2.order_no,
                                   t2.order_date,
                                   t2.ins_date,
                                   t2.st_date,
                                   t2.exp_date,
                                   t2.coupon_amt,
                                   t2.shop_name
                              FROM (SELECT ROWNUM AS RNUM,
                                           t1.*
                                      FROM (SELECT DECODE (a.status, '00', '대기', '10', '승인', '20', '발행(고객)', '30', '사용(고객)', '99', '폐기') status,
                                                   a.coupon_name,
                                                   a.coupon_no,
                                                   a.order_no,
                                                   a.order_date,
                                                   a.ins_date,
                                                   a.st_date,
                                                   a.exp_date,
                                                   a.coupon_amt,
                                                   c.shop_name
                                              FROM chain_coupon_mst a,
                                                   (SELECT *
                                                      FROM dorder
                                                     UNION ALL
                                                    SELECT *
                                                      FROM dorder_past) b,
                                                   shop_info c,
                                                   callcenter d
                                             WHERE a.order_no = b.order_no
                                               AND b.shop_cd = c.shop_cd
                                               AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                               AND b.TEST_GBN = 'N'
                                               AND NVL(b.CANCEL_CODE,'00') <> '30'
                                               AND c.cccode = d.cccode
                                               AND d.MCODE = 2
                                               AND b.order_date BETWEEN :date_begin AND :date_end
                                             ORDER BY b.order_no) t1
                                     WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                             WHERE (( :page - 1) * :row_count) < RNUM
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @"
                        SELECT count(*)
                          FROM chain_coupon_mst a,
                               (SELECT *
                                  FROM dorder
                                 UNION ALL
                                SELECT *
                                  FROM dorder_past) b,
                               shop_info c,
                               callcenter d
                         WHERE a.order_no = b.order_no
                           AND b.shop_cd = c.shop_cd
                           AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                           AND b.TEST_GBN = 'N'
                           AND NVL(b.CANCEL_CODE,'00') <> '30'
                           AND c.cccode = d.cccode
                           AND d.MCODE = 2
                           AND b.order_date BETWEEN :date_begin AND :date_end
                ";

                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/ChainCoupon/getCouponHistory : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items });
        }







        //브랜드쿠폰 발급 및 승인 스케줄러 테스트
        /// <summary>
        /// 스케줄러 생성 테스트
        /// </summary>
        [HttpPost("setSchedTest")]
        public async Task<IActionResult> setSchedTest()
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;

            List<object> items = new List<object>();
            //테스트db
            using IDbConnection db = new OracleConnection(Utils.oracleConnectStringTest);

            string sql = @$"
                            BEGIN
                              SYS.DBMS_SCHEDULER.CREATE_JOB
                                (
                                   job_name        => 'IS_DAEGU.SC_PD_100'
                                  ,start_date      => TO_TIMESTAMP_TZ('2022/06/11 10:00:00.200000 +09:00','yyyy/mm/dd hh24:mi:ss.ff tzh:tzm')
                                  ,repeat_interval => 'FREQ=DAILY;'
                                  ,end_date        => TO_TIMESTAMP_TZ('2022/06/16 10:00:00.200000 +09:00','yyyy/mm/dd hh24:mi:ss.ff tzh:tzm')
                                  ,job_class       => 'DEFAULT_JOB_CLASS'
                                  ,job_type        => 'STORED_PROCEDURE'
                                  ,job_action      => 'IS_DAEGU.SP_DAILY_CHAIN_COUPON_PD'
                                  ,comments        => '땅땅치킨 브랜드 쿠폰 발행 스케줄러 (6/11~6/16)'
                                );
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'RESTARTABLE'
                                 ,value     => TRUE);
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'LOGGING_LEVEL'
                                 ,value     => SYS.DBMS_SCHEDULER.LOGGING_RUNS);
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'MAX_FAILURES');
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'MAX_RUNS');
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'STOP_ON_WINDOW_CLOSE'
                                 ,value     => FALSE);
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'JOB_PRIORITY'
                                 ,value     => 3);
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'SCHEDULE_LIMIT');
                              SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
                                ( name      => 'IS_DAEGU.SC_PD_100'
                                 ,attribute => 'AUTO_DROP'
                                 ,value     => FALSE);

                              SYS.DBMS_SCHEDULER.ENABLE
                                (name                  => 'IS_DAEGU.SC_PD_100');
                            END;
                        ";

            try
            {
                db.Open();

                IDbCommand cmd = db.CreateCommand();
                cmd.CommandText = sql;

                cmd.ExecuteNonQuery();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {
                Rcode = "99";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg });
        }

    }
}
