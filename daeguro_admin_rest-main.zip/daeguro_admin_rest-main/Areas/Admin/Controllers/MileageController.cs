﻿using Dapper;
using DG_App_Rest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class MileageController : ControllerBase
    {
        // 마일리지 적립/사용 현황
        /// <summary>
        /// 마일리지 사용내역
        /// </summary>
        /// <remarks>
        /// service_gbn : 서비스 구분(빈값 : 전체, 0 : 주문, 1 : 특별관, 2 : 꽃배달, 3 : 로컬푸드, 4 : 전통시장, 5 : 전자관) <br />
        /// </remarks>
        [HttpGet("getMileageHistory")]
        public async Task<IActionResult> getMileageHistory(string service_gbn, string date_begin, string date_end, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();

                DynamicParameters param = new DynamicParameters();
                param.Add("service_gbn", service_gbn);
                param.Add("date_begin", date_begin);
                param.Add("date_end", date_end);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                 SELECT NVL(t2.order_no,'') order_no,
                                        t2.log_date,
                                        NVL(t2.cust_name,'') cust_name,
                                        TO_CHAR(t2.cust_code) cust_code,
                                        NVL(t2.mileage_amt, 0) mileage_amt,
                                        NVL(t2.mileage_use_amt, 0) mileage_use_amt,
                                        NVL(t2.shop_cd,'') shop_cd,
                                        NVL(t2.shop_name,'') shop_name,
                                        NVL(t2.service_gbn,'') service_gbn,
                                        t2.memo
                                    FROM (SELECT ROWNUM AS rnum, t1.*
                                            FROM (SELECT a.order_no,
                                                        a.log_date,
                                                        d.cust_name,
                                                        d.cust_code,
                                                        a.mileage_amt,
                                                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) as mileage_use_amt,
                                                        c.shop_cd,
                                                        c.shop_name,
                                                        c.service_gbn,
                                                        a.memo
                                                    FROM app_cust_mileage_log  a,
                                                        dorder                b,
                                                        shop_info             c,
                                                        (select mcode, cust_code, cust_name from app_customer 
                                                        union all 
                                                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                                                        callcenter            e
                                                    WHERE   a.order_no = b.order_no
                                                        AND b.shop_cd = c.shop_cd
                                                        AND c.cccode = e.cccode
                                                        AND e.mcode = 2
                                                        AND d.mcode = 2
                                                        AND a.app_cust_code = d.cust_code
                                                        and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                                        AND b.TEST_GBN = 'N'
                                                        AND NVL(b.cancel_code,'00')<>'30'
                                                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                                        AND a.log_date BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                           AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                                UNION ALL
                                                SELECT a.order_no,
                                                        a.log_date,
                                                        d.cust_name,
                                                        d.cust_code,
                                                        a.mileage_amt,
                                                        (case when a.log_gbn = '3' then b.mileage_use_amt else 0 end) as mileage_use_amt,
                                                        c.shop_cd,
                                                        c.shop_name,
                                                        c.service_gbn,
                                                        a.memo
                                                    FROM app_cust_mileage_log  a,
                                                        dorder_past           b,
                                                        shop_info             c,
                                                        (select mcode, cust_code, cust_name from app_customer 
                                                        union all 
                                                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                                                        callcenter            e
                                                    WHERE   a.order_no = b.order_no
                                                        AND b.shop_cd = c.shop_cd
                                                        AND c.cccode = e.cccode
                                                        AND e.mcode = 2
                                                        AND d.mcode = 2
                                                        AND a.app_cust_code = d.cust_code
                                                        and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                                        AND b.TEST_GBN = 'N'
                                                        AND NVL(b.cancel_code,'00')<>'30'
                                                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                                        AND a.log_date BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                                           AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                                ORDER BY log_date DESC) t1
                                            WHERE ROWNUM <= (( :page - 1) * :row_count) + :row_count) t2
                                    WHERE (( :page - 1) * :row_count) < rnum
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                sql = @"
                        SELECT COUNT (*)
                          FROM (SELECT  1
                                    FROM app_cust_mileage_log  a,
                                        dorder                b,
                                        shop_info             c,
                                        (select mcode, cust_code, cust_name from app_customer 
                                        union all 
                                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                                        callcenter            e
                                    WHERE   a.order_no = b.order_no
                                        AND b.shop_cd = c.shop_cd
                                        AND c.cccode = e.cccode
                                        AND e.mcode = 2
                                        AND d.mcode = 2
                                        AND a.app_cust_code = d.cust_code
                                        and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                        AND b.TEST_GBN = 'N'
                                        AND NVL(b.cancel_code,'00')<>'30'
                                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND a.log_date BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                            AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS')
                                UNION ALL
                                SELECT 1
                                    FROM app_cust_mileage_log  a,
                                        dorder_past           b,
                                        shop_info             c,
                                        (select mcode, cust_code, cust_name from app_customer 
                                        union all 
                                        select mcode, cust_code, cust_name from app_customer_deleted)  d,
                                        callcenter            e
                                    WHERE   a.order_no = b.order_no
                                        AND b.shop_cd = c.shop_cd
                                        AND c.cccode = e.cccode
                                        AND e.mcode = 2
                                        AND d.mcode = 2
                                        AND a.app_cust_code = d.cust_code
                                        and c.service_gbn like case when :service_gbn is null then '%' else :service_gbn end
                                        AND b.TEST_GBN = 'N'
                                        AND NVL(b.cancel_code,'00')<>'30'
                                        AND b.ORDER_TIME >= TO_DATE('2021080917','YYYYMMDDHH24')
                                        AND a.log_date BETWEEN to_date(:date_begin || ' 000000', 'YYYYMMDD HH24MISS')
                                                            AND to_date(:date_end || ' 235959', 'YYYYMMDD HH24MISS'))
                ";

                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items });
        }


        /// <summary>
        /// 마일리지 선입선출 대장
        /// </summary>
        /// <remarks>
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지 <br />
        /// keyword 고객코드
        /// </remarks>
        [HttpGet("getMileageInOut")]
        public async Task<IActionResult> getMileageInOut(string date_begin, string date_end, int mcode, string cust_gbn, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;
            
            List<object> items = new List<object>();
            List<object> sumItems = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요."; 

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_keyword", keyword);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                 SELECT T2.*
                                  FROM (SELECT to_char(ROWNUM) AS RNUM, T1.*
                                          FROM (  SELECT    M.MCODE,
                                                             M.MNAME,
                                                             X.CUST_GBN,
                                                             CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                             X.CUST_CODE,
                                                             SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                             X.CUST_MILEAGE,
                                                             Y.REMAIN_AMT AS LOG_CUST_MILEAGE, 
                                                             Y.IN_CNT, 
                                                             Y.IN_AMT,
                                                             Y.ORDER_IN_CNT,
                                                             Y.ORDER_IN_AMT,
                                                             Y.SALE_IN_CNT,
                                                             Y.SALE_IN_AMT,  
                                                             Y.ORDER_OUT_AMT,
                                                             Y.SALE_OUT_AMT,               
                                                             Y.OUT_AMT,
                                                             Q.TERMINATE_AMT
                                                   FROM ( 
                                                          SELECT  A.MCODE,
                                                                  '1' AS CUST_GBN,
                                                                  A.CUST_CODE,
                                                                  A.CUST_NAME,
                                                                  A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          UNION ALL
                                                          SELECT A.MCODE,
                                                                 '3' AS CUST_GBN,
                                                                 A.CUST_CODE,
                                                                 A.CUST_NAME,
                                                                 A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER_DELETED A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                                           ) X, 
                                                        ( SELECT  D.APP_CUST_CODE,
                                                                  SUM(NVL(D.IN_AMT,0) - NVL(D.OUT_AMT,0))   AS REMAIN_AMT, 
                                                                  SUM(D.IN_CNT)         AS IN_CNT, 
                                                                  SUM(D.IN_AMT)         AS IN_AMT,
                                                                  SUM(D.ORDER_IN_CNT)   AS ORDER_IN_CNT,
                                                                  SUM(D.ORDER_IN_AMT)   AS ORDER_IN_AMT,
                                                                  SUM(D.SALE_IN_CNT)    AS SALE_IN_CNT,
                                                                  SUM(D.SALE_IN_AMT)    AS SALE_IN_AMT,
                                                                  SUM(D.ORDER_OUT_AMT)  AS ORDER_OUT_AMT,
                                                                  SUM(D.SALE_OUT_AMT)   AS SALE_OUT_AMT,
                                                                  SUM(D.OUT_AMT)       AS OUT_AMT
                                                          FROM ( 
                                                                     SELECT   /*+ full(A) parallel(A 4) */     
                                                                               A.APP_CUST_CODE, 
                                                                               A.LOGNO ,                                                                
                                                                               SUM(1)                                         AS IN_CNT  ,
                                                                               SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS NOT NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO  IS NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END)    AS SALE_OUT_AMT  ,
                                                                               SUM(NVL(C.OUT_AMT,0))                                                AS OUT_AMT
                                                                      FROM    (select * from APP_CUST_MILEAGE_REMAIN
                                                                      where  LOG_GBN       = '1'
                                                                      AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS'))  A,
                                                                       ( SELECT    B.APP_CUST_CODE, 
                                                                                 B.LOGNO,
                                                                                     SUM(B.CHARGE_AMT)              AS OUT_AMT 
                                                                              FROM    APP_CUST_MILEAGE_REMAIN B  
                                                                              WHERE  B.LOG_GBN = '3'
                                                                              AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                              GROUP BY B.APP_CUST_CODE, 
                                                                                       B.LOGNO ) C
                                                                      WHERE  A.APP_CUST_CODE = C.APP_CUST_CODE (+)
                                                                      AND    A.LOGNO         = C.LOGNO         (+)
                                                                      GROUP BY A.APP_CUST_CODE, 
                                                                               A.LOGNO 
                                                                      UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                                 
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS SALE_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                               
                                                                                   ( SELECT MEMO
                                                                                          FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                          WHERE C.LOGNO = A.LOGNO 
                                                                                          AND   C.LOG_GBN = '1')as MEMO,                                 
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A
                                                                          WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO) D
                                                              GROUP BY D.APP_CUST_CODE ) Y,  
                                                              MEMBERSHIP M,
                                                              (select ORI_REMAIN_AMT, MILEAGE_AMT AS TERMINATE_AMT, APP_CUST_CODE from app_cust_mileage_log
                                                                 where memo like '%탈퇴%'
                                                                 and to_char(log_date,'YYYYMMDD') >= '20210817'
                                                                 order by log_date desc) Q
                                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                                           AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                                           AND  X.MCODE  = M.MCODE
                                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))) T1
                                                         WHERE ROWNUM <= ((:page - 1) * :row_count) + :row_count) T2
                                                 WHERE ((:page - 1) * :row_count) < RNUM
                                ";

                // 쿼리 값을 받을 임시 변수 temp 선언
                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                // 선언해놓은 list 변수에 쿼리 결과가 있는 temp 변수값을 ToList로 입력.
                items = temp.ToList();

                sql = @"
                        SELECT    count(*)
                                                   FROM ( 
                                                          SELECT  A.MCODE,
                                                                  '1' AS CUST_GBN,
                                                                  A.CUST_CODE,
                                                                  A.CUST_NAME,
                                                                  A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          UNION ALL
                                                          SELECT A.MCODE,
                                                                 '3' AS CUST_GBN,
                                                                 A.CUST_CODE,
                                                                 A.CUST_NAME,
                                                                 A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER_DELETED A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                                           ) X, 
                                                        ( SELECT  D.APP_CUST_CODE,
                                                                  SUM(NVL(D.IN_AMT,0) - NVL(D.OUT_AMT,0))   AS REMAIN_AMT, 
                                                                  SUM(D.IN_CNT)         AS IN_CNT, 
                                                                  SUM(D.IN_AMT)         AS IN_AMT,
                                                                  SUM(D.ORDER_IN_CNT)   AS ORDER_IN_CNT,
                                                                  SUM(D.ORDER_IN_AMT)   AS ORDER_IN_AMT,
                                                                  SUM(D.SALE_IN_CNT)    AS SALE_IN_CNT,
                                                                  SUM(D.SALE_IN_AMT)    AS SALE_IN_AMT,
                                                                  SUM(D.ORDER_OUT_AMT)  AS ORDER_OUT_AMT,
                                                                  SUM(D.SALE_OUT_AMT)   AS SALE_OUT_AMT,
                                                                  SUM(D.OUT_AMT)       AS OUT_AMT
                                                          FROM ( 
                                                                     SELECT   /*+ full(A) parallel(A 4) */     
                                                                               A.APP_CUST_CODE, 
                                                                               A.LOGNO ,                                                                
                                                                               SUM(1)                                         AS IN_CNT  ,
                                                                               SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO IS NOT NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                               SUM(CASE WHEN ORDER_NO  IS NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END)    AS SALE_OUT_AMT  ,
                                                                               SUM(NVL(C.OUT_AMT,0))                                                AS OUT_AMT
                                                                      FROM    (select * from APP_CUST_MILEAGE_REMAIN
                                                                      where  LOG_GBN       = '1'
                                                                      AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS'))  A,
                                                                       ( SELECT    B.APP_CUST_CODE, 
                                                                                 B.LOGNO,
                                                                                     SUM(B.CHARGE_AMT)              AS OUT_AMT 
                                                                              FROM    APP_CUST_MILEAGE_REMAIN B  
                                                                              WHERE  B.LOG_GBN = '3'
                                                                              AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                              GROUP BY B.APP_CUST_CODE, 
                                                                                       B.LOGNO ) C
                                                                      WHERE  A.APP_CUST_CODE = C.APP_CUST_CODE (+)
                                                                      AND    A.LOGNO         = C.LOGNO         (+)
                                                                      GROUP BY A.APP_CUST_CODE, 
                                                                               A.LOGNO 
                                                                      UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                                 
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS SALE_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                               
                                                                                   ( SELECT MEMO
                                                                                          FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                          WHERE C.LOGNO = A.LOGNO 
                                                                                          AND   C.LOG_GBN = '1')as MEMO,                                 
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A
                                                                          WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO) D
                                                              GROUP BY D.APP_CUST_CODE ) Y,  
                                                              MEMBERSHIP M,
                                                              (select ORI_REMAIN_AMT, MILEAGE_AMT AS TERMINATE_AMT, APP_CUST_CODE from app_cust_mileage_log
                                                                 where memo like '%탈퇴%'
                                                                 and to_char(log_date,'YYYYMMDD') >= '20210817'
                                                                 order by log_date desc) Q
                                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                                           AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                                           AND  X.MCODE  = M.MCODE
                                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                ";

                // Total Count
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @"
                         SELECT nvl(COUNT(*),0) AS COUNT,
                                nvl(SUM(CUST_MILEAGE),0) AS SUM_CUST_MILEAGE,
                                nvl(SUM(LOG_CUST_MILEAGE),0) AS SUM_LOG_CUST_MILEAGE,
                                nvl(SUM(IN_CNT),0) AS SUM_IN_CNT,
                                nvl(SUM(IN_AMT),0) AS SUM_IN_AMT,
                                nvl(SUM(ORDER_IN_CNT),0) AS SUM_ORDER_IN_CNT,
                                nvl(SUM(ORDER_IN_AMT),0) AS SUM_ORDER_IN_AMT,
                                nvl(SUM(SALE_IN_CNT),0) AS SUM_SALE_IN_CNT,
                                nvl(SUM(SALE_IN_AMT),0) AS SUM_SALE_IN_AMT,
                                nvl(SUM(ORDER_OUT_AMT),0) AS SUM_ORDER_OUT_AMT,
                                nvl(SUM(SALE_OUT_AMT),0) AS SUM_SALE_OUT_AMT,
                                nvl(SUM(OUT_AMT),0) AS SUM_OUT_AMT,
                                nvl(SUM(TERMINATE_AMT),0) AS SUM_TERMINATE_AMT
                                FROM(  SELECT    M.MCODE,
                                                    M.MNAME,
                                                    X.CUST_GBN,
                                                    CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                    X.CUST_CODE,
                                                    SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                    X.CUST_MILEAGE,
                                                    Y.REMAIN_AMT AS LOG_CUST_MILEAGE, 
                                                    Y.IN_CNT, 
                                                    Y.IN_AMT,
                                                    Y.ORDER_IN_CNT,
                                                    Y.ORDER_IN_AMT,
                                                    Y.SALE_IN_CNT,
                                                    Y.SALE_IN_AMT,  
                                                    Y.ORDER_OUT_AMT,
                                                    Y.SALE_OUT_AMT,               
                                                    Y.OUT_AMT,
                                                    Q.TERMINATE_AMT
                                    FROM ( 
                                            SELECT  A.MCODE,
                                                    '1' AS CUST_GBN,
                                                    A.CUST_CODE,
                                                    A.CUST_NAME,
                                                    A.MILEAGE  AS CUST_MILEAGE
                                            FROM   APP_CUSTOMER A
                                            WHERE  CUST_ID_GBN <> 'Z'
                                            AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                            AND   TEST_GBN = 'R' 
                                            AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            UNION ALL
                                            SELECT A.MCODE,
                                                    '3' AS CUST_GBN,
                                                    A.CUST_CODE,
                                                    A.CUST_NAME,
                                                    A.MILEAGE  AS CUST_MILEAGE
                                            FROM   APP_CUSTOMER_DELETED A
                                            WHERE  CUST_ID_GBN <> 'Z'
                                            AND   TEST_GBN = 'R' 
                                            AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')
                                            AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                            ) X, 
                                        ( SELECT  D.APP_CUST_CODE,
                                                    SUM(NVL(D.IN_AMT,0) - NVL(D.OUT_AMT,0))   AS REMAIN_AMT, 
                                                    SUM(D.IN_CNT)         AS IN_CNT, 
                                                    SUM(D.IN_AMT)         AS IN_AMT,
                                                    SUM(D.ORDER_IN_CNT)   AS ORDER_IN_CNT,
                                                    SUM(D.ORDER_IN_AMT)   AS ORDER_IN_AMT,
                                                    SUM(D.SALE_IN_CNT)    AS SALE_IN_CNT,
                                                    SUM(D.SALE_IN_AMT)    AS SALE_IN_AMT,
                                                    SUM(D.ORDER_OUT_AMT)  AS ORDER_OUT_AMT,
                                                    SUM(D.SALE_OUT_AMT)   AS SALE_OUT_AMT,
                                                    SUM(D.OUT_AMT)       AS OUT_AMT
                                            FROM ( 
                                                        SELECT   /*+ full(A) parallel(A 4) */     
                                                                A.APP_CUST_CODE,                                                               
                                                                SUM(1)                                         AS IN_CNT  ,
                                                                SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                SUM(CASE WHEN ORDER_NO IS NOT NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                SUM(CASE WHEN ORDER_NO  IS NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END)    AS SALE_OUT_AMT  ,
                                                                SUM(NVL(C.OUT_AMT,0))                                                AS OUT_AMT
                                                        FROM    (select * from APP_CUST_MILEAGE_REMAIN
                                                        where  LOG_GBN       = '1'
                                                        AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS'))  A,
                                                        ( SELECT    B.APP_CUST_CODE, 
                                                                    B.LOGNO,
                                                                        SUM(B.CHARGE_AMT)              AS OUT_AMT 
                                                                FROM    APP_CUST_MILEAGE_REMAIN B  
                                                                WHERE  B.LOG_GBN = '3'
                                                                AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                GROUP BY B.APP_CUST_CODE, 
                                                                        B.LOGNO ) C
                                                        WHERE  A.APP_CUST_CODE = C.APP_CUST_CODE (+)
                                                        AND    A.LOGNO         = C.LOGNO         (+)
                                                        GROUP BY A.APP_CUST_CODE
                                                        UNION ALL 
                                                        SELECT APP_CUST_CODE,                                 
                                                               -1                           AS IN_CNT  ,
                                                               SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                               0                            AS ORDER_IN_CNT  ,
                                                               0                            AS ORDER_IN_AMT  ,
                                                               -1                           AS SALE_IN_CNT  ,
                                                               SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                               0                            AS ORDER_OUT_AMT  ,
                                                               0                            AS SALE_OUT_AMT  ,
                                                               0                            AS OUT_AMT 
                                                               from(      
                                                                SELECT A.APP_CUST_CODE,                                    
                                                                       A.CHARGE_AMT
                                                              FROM     APP_CUST_MILEAGE_REMAIN A
                                                              WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                              AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                              and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                              and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                              )
                                                              GROUP BY APP_CUST_CODE ) D
                                                GROUP BY D.APP_CUST_CODE ) Y,  
                                                MEMBERSHIP M,
                                                (select ORI_REMAIN_AMT, MILEAGE_AMT AS TERMINATE_AMT, APP_CUST_CODE from app_cust_mileage_log
                                                    where memo like '%탈퇴%'
                                                    and to_char(log_date,'YYYYMMDD') >= '20210817'
                                                    order by log_date desc) Q
                                            WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                            AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                            AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                            AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                            AND  X.MCODE  = M.MCODE
                                            AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                                ) Z
                ";

                // 합계 쿼리
                var sumTemp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                sumItems = sumTemp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Mileage/getMileageInOut : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items, sumData = sumItems });
        }

        /// <summary>
        /// 마일리지 선입선출 대장 v2
        /// </summary>
        /// <remarks>
        /// * 전일내역까지 조회가능 <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지, %. 전체 <br />
        /// keyword 고객코드 <br />
        /// [response] <br />
        /// 가입구분 CUST_GBN_NM <br />
        /// 고객코드 CUST_CODE <br />
        /// 고객명 CUST_NAME <br />
        /// 마일리지 잔액 CUST_MILEAGE <br />
        /// 대장잔액 LOG_CUST_MILEAGE <br />
        /// 충전건수 IN_CNT <br />
        /// 충전합계 IN_AMT <br />
        /// 주문충전건수 ORDER_IN_CNT <br />
        /// 주문충전금액 ORDER_IN_AMT <br />
        /// 판매충전건수 SALE_IN_CNT <br />
        /// 판매충전금액 SALE_IN_AMT <br />
        /// 택시충전건수 TAXI_IN_CNT <br />
        /// 택시충전금액 TAXI_IN_AMT <br />
        /// 주문차감금액 ORDER_OUT_AMT <br />
        /// 택시차감금액 TAXI_OUT_AMT <br />
        /// 차감합계 OUT_AMT <br />
        /// 탈퇴마일리지 TERMINATE_AMT <br />
        /// <br />
        /// sumData 합계정보 <br />
        /// 마일리지 잔액부터 탈퇴마일리지까지 SUM_칼럼명 표기
        /// </remarks>
        [HttpGet("getMileageInOut2")]
        public async Task<IActionResult> getMileageInOut2(string date_begin, string date_end, int mcode, string cust_gbn, string keyword, string page, string rows)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            string RtotalCount = string.Empty;

            List<object> items = new List<object>();
            List<object> sumItems = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_keyword", keyword);
                param.Add("page", page);
                param.Add("row_count", rows);

                string sql = @"
                                 SELECT T2.*
                                  FROM (SELECT to_char(ROWNUM) AS RNUM, T1.*
                                          FROM (  SELECT    M.MCODE,
                                                             M.MNAME,
                                                             X.CUST_GBN,
                                                             CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                             X.CUST_CODE,
                                                             SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                             X.CUST_MILEAGE,
                                                             Y.IN_AMT - Y.OUT_AMT AS LOG_CUST_MILEAGE, 
                                                             Y.IN_CNT, 
                                                             Y.IN_AMT,
                                                             Y.ORDER_IN_CNT,
                                                             Y.ORDER_IN_AMT,
                                                             Y.SALE_IN_CNT,
                                                             Y.SALE_IN_AMT,
                                                             Y.TAXI_IN_CNT,
                                                             Y.TAXI_IN_AMT,  
                                                             Y.ORDER_OUT_AMT,
                                                             Y.TAXI_OUT_AMT,              
                                                             Y.OUT_AMT,
                                                             nvl(Q.TERMINATE_AMT,0) TERMINATE_AMT
                                                   FROM ( 
                                                          SELECT  A.MCODE,
                                                                  '1' AS CUST_GBN,
                                                                  A.CUST_CODE,
                                                                  A.CUST_NAME,
                                                                  A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND    A.MCODE   = :in_mcode
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          UNION ALL
                                                          SELECT A.MCODE,
                                                                 '3' AS CUST_GBN,
                                                                 A.CUST_CODE,
                                                                 A.CUST_NAME,
                                                                 A.MILEAGE  AS CUST_MILEAGE
                                                          FROM   APP_CUSTOMER_DELETED A
                                                          WHERE  CUST_ID_GBN <> 'Z'
                                                          AND   TEST_GBN = 'R' 
                                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                                          AND    A.MCODE   = :in_mcode
                                                           ) X, 
                                                        (SELECT   /*+ full(A) parallel(A 4) */     
                                                                   APP_CUST_CODE,                                                                
                                                                   SUM(1)                                         AS IN_CNT  ,
                                                                   SUM(MILEAGE_AMT )                             AS IN_AMT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                                   0                    AS ORDER_OUT_AMT  ,
                                                                   0                    AS TAXI_OUT_AMT  ,
                                                                   0                    AS OUT_AMT
                                                          FROM APP_CUST_MILEAGE_REMAIN2
                                                          where  LOG_GBN       = '1'
                                                          AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                          and    LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          GROUP BY APP_CUST_CODE
                                                         UNION ALL 
                                                            SELECT       APP_CUST_CODE,                                
                                                               0                            AS IN_CNT  ,
                                                               0                            AS IN_AMT  ,
                                                               0                            AS ORDER_IN_CNT  ,
                                                               0                            AS ORDER_IN_AMT  ,
                                                               0                            AS SALE_IN_CNT  ,
                                                               0                            AS SALE_IN_AMT  ,
                                                               0                            AS TAXI_IN_CNT  ,
                                                               0                            AS TAXI_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' THEN NVL(charge_amt,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN NVL(charge_amt,0) ELSE 0 END)    AS TAXI_OUT_AMT  ,
                                                           SUM(NVL(charge_amt,0))                                                AS OUT_AMT
                                                          FROM    APP_CUST_MILEAGE_REMAIN2 B  
                                                          WHERE  B.LOG_GBN = '3'
                                                          AND    B.memo like '%(선입/선출차감)'
                                                          AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                          and    b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          and    b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                          GROUP BY B.APP_CUST_CODE
                                                              UNION ALL 
                                                            SELECT APP_CUST_CODE,                                
                                                                   -1                           AS IN_CNT  ,
                                                                   SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                   0                            AS ORDER_IN_CNT  ,
                                                                   0                            AS ORDER_IN_AMT  ,
                                                                   -1                           AS SALE_IN_CNT  ,
                                                                   SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                   0                            AS TAXI_IN_CNT  ,
                                                                   0                            AS TAXI_IN_AMT  ,
                                                                   0                            AS ORDER_OUT_AMT  ,
                                                                   0                            AS TAXI_OUT_AMT  ,
                                                                   0                            AS OUT_AMT 
                                                                   from(      
                                                                    SELECT A.APP_CUST_CODE, 
                                                                           B.LOGNO ,                            
                                                                           B.MEMO,
                                                                           B.system_gbn,
                                                                           B.order_no,                            
                                                                           A.CHARGE_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                                  WHERE a.memo = to_char(b.logno)
                                                                  --AND a.memo not like '%(선입/선출차감)'
                                                                  and b.log_gbn = '1'
                                                                  AND      A.log_gbn = '3'
                                                                  AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  ) D
                                                      GROUP BY D.APP_CUST_CODE ) Y,
                                                      (select APP_CUST_CODE, SUM(charge_amt) * -1 AS TERMINATE_AMT from app_cust_mileage_remain2
                                                         where memo like '회원탈퇴, (선입/선출차감)'
                                                         and to_char(log_date,'YYYYMMDDHH24') >= '2021080917'
                                                         GROUP BY APP_CUST_CODE) Q,
                                                         MEMBERSHIP M
                                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                                           AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                                           AND  X.MCODE  = M.MCODE
                                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))) T1
                                                         WHERE ROWNUM <= ((:page - 1) * :row_count) + :row_count) T2
                                                 WHERE ((:page - 1) * :row_count) < RNUM
                                ";

                // 쿼리 값을 받을 임시 변수 temp 선언
                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                // 선언해놓은 list 변수에 쿼리 결과가 있는 temp 변수값을 ToList로 입력.
                items = temp.ToList();

                sql = @"
                        select count(*)
                                    FROM ( 
                                          SELECT  A.MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = :in_mcode
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT A.MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = :in_mcode
                                           ) X, 
                                        (SELECT   /*+ full(A) parallel(A 4) */     
                                                           APP_CUST_CODE,                                                                
                                                           SUM(1)                                         AS IN_CNT  ,
                                                           SUM(MILEAGE_AMT )                             AS IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                           0                    AS ORDER_OUT_AMT  ,
                                                           0                    AS TAXI_OUT_AMT  ,
                                                           0                    AS OUT_AMT
                                                  FROM APP_CUST_MILEAGE_REMAIN2
                                                  where  LOG_GBN       = '1'
                                                  AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                  and    LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  GROUP BY APP_CUST_CODE
                                                 UNION ALL 
                                                    SELECT       APP_CUST_CODE,                                
                                                       0                            AS IN_CNT  ,
                                                       0                            AS IN_AMT  ,
                                                       0                            AS ORDER_IN_CNT  ,
                                                       0                            AS ORDER_IN_AMT  ,
                                                       0                            AS SALE_IN_CNT  ,
                                                       0                            AS SALE_IN_AMT  ,
                                                       0                            AS TAXI_IN_CNT  ,
                                                       0                            AS TAXI_IN_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' THEN NVL(charge_amt,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN NVL(charge_amt,0) ELSE 0 END)    AS TAXI_OUT_AMT  ,
                                                   SUM(NVL(charge_amt,0))                                                AS OUT_AMT
                                                  FROM    APP_CUST_MILEAGE_REMAIN2 B  
                                                  WHERE  B.LOG_GBN = '3'
                                                  AND    B.memo like '%(선입/선출차감)'
                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                  and    b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  and    b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                  GROUP BY B.APP_CUST_CODE
                                                      UNION ALL 
                                                    SELECT APP_CUST_CODE,                                
                                                           -1                           AS IN_CNT  ,
                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                           0                            AS ORDER_IN_CNT  ,
                                                           0                            AS ORDER_IN_AMT  ,
                                                           -1                           AS SALE_IN_CNT  ,
                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                           0                            AS TAXI_IN_CNT  ,
                                                           0                            AS TAXI_IN_AMT  ,
                                                           0                            AS ORDER_OUT_AMT  ,
                                                           0                            AS TAXI_OUT_AMT  ,
                                                           0                            AS OUT_AMT 
                                                           from(      
                                                            SELECT A.APP_CUST_CODE, 
                                                                   B.LOGNO ,                            
                                                                   B.MEMO,
                                                                   B.system_gbn,
                                                                   B.order_no,                            
                                                                   A.CHARGE_AMT
                                                          FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                          WHERE a.memo = to_char(b.logno)
                                                          --AND a.memo not like '%(선입/선출차감)'
                                                          and b.log_gbn = '1'
                                                          AND      A.log_gbn = '3'
                                                          AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                          ) D
                                              GROUP BY D.APP_CUST_CODE ) Y
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                ";

                // Total Count
                RtotalCount = await db.ExecuteScalarAsync<string>(sql, param, commandType: CommandType.Text);

                sql = @"
                         SELECT nvl(COUNT(*),0) AS COUNT,
                                nvl(SUM(CUST_MILEAGE),0) AS SUM_CUST_MILEAGE,
                                nvl(SUM(IN_AMT),0) - nvl(SUM(OUT_AMT),0) AS SUM_LOG_CUST_MILEAGE,
                                nvl(SUM(IN_CNT),0) AS SUM_IN_CNT,
                                nvl(SUM(IN_AMT),0) AS SUM_IN_AMT,
                                nvl(SUM(ORDER_IN_CNT),0) AS SUM_ORDER_IN_CNT,
                                nvl(SUM(ORDER_IN_AMT),0) AS SUM_ORDER_IN_AMT,
                                nvl(SUM(SALE_IN_CNT),0) AS SUM_SALE_IN_CNT,
                                nvl(SUM(SALE_IN_AMT),0) AS SUM_SALE_IN_AMT,
                                nvl(SUM(TAXI_IN_CNT),0) AS SUM_TAXI_IN_CNT,
                                nvl(SUM(TAXI_IN_AMT),0) AS SUM_TAXI_IN_AMT,
                                nvl(SUM(ORDER_OUT_AMT),0) AS SUM_ORDER_OUT_AMT,
                                nvl(SUM(TAXI_OUT_AMT),0) AS SUM_TAXI_OUT_AMT,
                                nvl(SUM(OUT_AMT),0) AS SUM_OUT_AMT,
                                nvl(SUM(TERMINATE_AMT),0) AS SUM_TERMINATE_AMT
                                FROM ( 
                                          SELECT  A.MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = :in_mcode
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT A.MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                          AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = :in_mcode
                                           ) X, 
                                        (SELECT   /*+ full(A) parallel(A 4) */     
                                                           APP_CUST_CODE,                                                                
                                                           SUM(1)                                         AS IN_CNT  ,
                                                           SUM(MILEAGE_AMT )                             AS IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NOT NULL THEN MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'D' AND ORDER_NO IS  NULL THEN MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                           SUM(CASE WHEN SYSTEM_GBN = 'T' THEN MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                           0                    AS ORDER_OUT_AMT  ,
                                                           0                    AS TAXI_OUT_AMT  ,
                                                           0                    AS OUT_AMT
                                                  FROM APP_CUST_MILEAGE_REMAIN2
                                                  where  LOG_GBN       = '1'
                                                  AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                  and    LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  GROUP BY APP_CUST_CODE
                                                 UNION ALL 
                                                    SELECT       APP_CUST_CODE,                                
                                                       0                            AS IN_CNT  ,
                                                       0                            AS IN_AMT  ,
                                                       0                            AS ORDER_IN_CNT  ,
                                                       0                            AS ORDER_IN_AMT  ,
                                                       0                            AS SALE_IN_CNT  ,
                                                       0                            AS SALE_IN_AMT  ,
                                                       0                            AS TAXI_IN_CNT  ,
                                                       0                            AS TAXI_IN_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'D' THEN NVL(charge_amt,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                   SUM(CASE WHEN SYSTEM_GBN = 'T' THEN NVL(charge_amt,0) ELSE 0 END)    AS TAXI_OUT_AMT  ,
                                                   SUM(NVL(charge_amt,0))                                                AS OUT_AMT
                                                  FROM    APP_CUST_MILEAGE_REMAIN2 B  
                                                  WHERE  B.LOG_GBN = '3'
                                                  AND    B.memo like '%(선입/선출차감)'
                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                  and    b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                  and    b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                  GROUP BY B.APP_CUST_CODE
                                                      UNION ALL 
                                                    SELECT APP_CUST_CODE,                                
                                                           -1                           AS IN_CNT  ,
                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                           0                            AS ORDER_IN_CNT  ,
                                                           0                            AS ORDER_IN_AMT  ,
                                                           -1                           AS SALE_IN_CNT  ,
                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                           0                            AS TAXI_IN_CNT  ,
                                                           0                            AS TAXI_IN_AMT  ,
                                                           0                            AS ORDER_OUT_AMT  ,
                                                           0                            AS TAXI_OUT_AMT  ,
                                                           0                            AS OUT_AMT 
                                                           from(      
                                                            SELECT A.APP_CUST_CODE, 
                                                                   B.LOGNO ,                            
                                                                   B.MEMO,
                                                                   B.system_gbn,
                                                                   B.order_no,                            
                                                                   A.CHARGE_AMT
                                                          FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                          WHERE a.memo = to_char(b.logno)
                                                          --AND a.memo not like '%(선입/선출차감)'
                                                          and b.log_gbn = '1'
                                                          AND      A.log_gbn = '3'
                                                          AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                          ) D
                                              GROUP BY D.APP_CUST_CODE ) Y,
                                              (select APP_CUST_CODE, SUM(charge_amt) * -1 AS TERMINATE_AMT from app_cust_mileage_remain2
                                                 where memo like '회원탈퇴, (선입/선출차감)'
                                                 and to_char(log_date,'YYYYMMDDHH24') >= '2021080917'
                                                 GROUP BY APP_CUST_CODE) Q
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                           AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                ";

                // 합계 쿼리
                var sumTemp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                sumItems = sumTemp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Mileage/getMileageInOut2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, totalCount = RtotalCount, data = items, sumData = sumItems });
        }

        //마일리지 선입선출 합계 쿼리
        [HttpGet("getMileageInOutSum")]
        public async Task<IActionResult> getMileageInOutSum(string date_begin, string date_end, int mcode, string cust_gbn, string keyword)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            Object data = string.Empty;
            List<object> Rdata = new List<object>();

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);

                DynamicParameters param = new DynamicParameters();

                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_keyword", keyword);

                db.Open();

                string sql = @"
                                SELECT nvl(COUNT(*),0) AS COUNT,
                                 nvl(SUM(CUST_MILEAGE),0) AS SUM_CUST_MILEAGE,
                                 nvl(SUM(LOG_CUST_MILEAGE),0) AS SUM_LOG_CUST_MILEAGE,
                                 nvl(SUM(IN_CNT),0) AS SUM_IN_CNT,
                                 nvl(SUM(IN_AMT),0) AS SUM_IN_AMT,
                                 nvl(SUM(ORDER_IN_CNT),0) AS SUM_ORDER_IN_CNT,
                                 nvl(SUM(ORDER_IN_AMT),0) AS SUM_ORDER_IN_AMT,
                                 nvl(SUM(SALE_IN_CNT),0) AS SUM_SALE_IN_CNT,
                                 nvl(SUM(SALE_IN_AMT),0) AS SUM_SALE_IN_AMT,
                                 nvl(SUM(ORDER_OUT_AMT),0) AS SUM_ORDER_OUT_AMT,
                                 nvl(SUM(SALE_OUT_AMT),0) AS SUM_SALE_OUT_AMT,
                                 nvl(SUM(OUT_AMT),0) AS SUM_OUT_AMT
                                 FROM(  SELECT    M.MCODE,
                                                     M.MNAME,
                                                     X.CUST_GBN,
                                                     CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                     X.CUST_CODE,
                                                     SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                     X.CUST_MILEAGE,
                                                     Y.REMAIN_AMT AS LOG_CUST_MILEAGE, 
                                                     Y.IN_CNT, 
                                                     Y.IN_AMT,
                                                     Y.ORDER_IN_CNT,
                                                     Y.ORDER_IN_AMT,
                                                     Y.SALE_IN_CNT,
                                                     Y.SALE_IN_AMT,  
                                                     Y.ORDER_OUT_AMT,
                                                     Y.SALE_OUT_AMT,               
                                                     Y.OUT_AMT
                                       FROM ( 
                                              SELECT  A.MCODE,
                                                      '1' AS CUST_GBN,
                                                      A.CUST_CODE,
                                                      A.CUST_NAME,
                                                      A.MILEAGE  AS CUST_MILEAGE
                                              FROM   APP_CUSTOMER A
                                              WHERE  CUST_ID_GBN <> 'Z'
                                              AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                              AND   TEST_GBN = 'R' 
                                              UNION ALL
                                              SELECT A.MCODE,
                                                     '3' AS CUST_GBN,
                                                     A.CUST_CODE,
                                                     A.CUST_NAME,
                                                     A.MILEAGE  AS CUST_MILEAGE
                                              FROM   APP_CUSTOMER_DELETED A
                                              WHERE  CUST_ID_GBN <> 'Z'
                                              AND   TEST_GBN = 'R' 
                                              AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                               ) X, 
                                            ( SELECT  D.APP_CUST_CODE,
                                                      SUM(NVL(D.IN_AMT,0) - NVL(D.OUT_AMT,0))   AS REMAIN_AMT, 
                                                      SUM(D.IN_CNT)         AS IN_CNT, 
                                                      SUM(D.IN_AMT)         AS IN_AMT,
                                                      SUM(D.ORDER_IN_CNT)   AS ORDER_IN_CNT,
                                                      SUM(D.ORDER_IN_AMT)   AS ORDER_IN_AMT,
                                                      SUM(D.SALE_IN_CNT)    AS SALE_IN_CNT,
                                                      SUM(D.SALE_IN_AMT)    AS SALE_IN_AMT,
                                                      SUM(D.ORDER_OUT_AMT)  AS ORDER_OUT_AMT,
                                                      SUM(D.SALE_OUT_AMT)   AS SALE_OUT_AMT,
                                                      SUM(D.OUT_AMT)       AS OUT_AMT
                                              FROM ( 
                                                         SELECT   /*+ full(A) parallel(A 4) */     
                                                                   A.APP_CUST_CODE, 
                                                                   A.LOGNO ,                                                                
                                                                   SUM(1)                                         AS IN_CNT  ,
                                                                   SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS NOT NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO  IS NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END)    AS SALE_OUT_AMT  ,
                                                                   SUM(NVL(C.OUT_AMT,0))                                                AS OUT_AMT
                                                          FROM    (select * from APP_CUST_MILEAGE_REMAIN
                                                          where  LOG_GBN       = '1'
                                                          AND    LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS'))  A,
                                                           ( SELECT    B.APP_CUST_CODE, 
                                                                     B.LOGNO,
                                                                         SUM(B.CHARGE_AMT)              AS OUT_AMT 
                                                                  FROM    APP_CUST_MILEAGE_REMAIN B  
                                                                  WHERE  B.LOG_GBN = '3'
                                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  GROUP BY B.APP_CUST_CODE, 
                                                                           B.LOGNO ) C
                                                          WHERE  A.APP_CUST_CODE = C.APP_CUST_CODE (+)
                                                          AND    A.LOGNO         = C.LOGNO         (+)
                                                          GROUP BY A.APP_CUST_CODE, 
                                                                   A.LOGNO ) D
                                                  GROUP BY D.APP_CUST_CODE ) Y,  MEMBERSHIP M
                                               WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                               AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                               AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                               AND  X.MCODE  = M.MCODE
                                               AND (:in_keyword IS NULL OR (X.cust_code = :in_keyword))
                                  ) Z
                ";

                data = await db.QuerySingleAsync(sql, param, commandType: CommandType.Text);


                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Mileage/getMileageInOutSum : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, count = data });
        }


        /// <summary>
        /// 관리앱 마일리지(판매) 선입선출 대장, 대구로 통계(회계)
        /// </summary>
        /// <remarks>
        /// sale_gbn 판매구분 <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지
        /// </remarks>
        [HttpGet("getSaleMileageInOut")]
        public async Task<IActionResult> getSaleMileageInOut(string date_begin, string date_end, int mcode, string sale_gbn, string cust_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();	// Object 타입으로 list 선언 (쿼리 결과물 담아서 리턴해주는 용도)

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";	// 에러코드
                Rmsg = "조회 기간을 설정해 주세요.";   // 에러메시지

                // return Ok <= 외부로 리턴해줄 때 Ok라고 적고 보내주는 것들 나열해주면 된다고 함.
                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_sale_gbn", sale_gbn);
                param.Add("in_cust_gbn", cust_gbn);

                string sql = @"
                                 SELECT  /*+ use_hash(X Y) no_merge(X) no_merge(Y) */    M.MCODE,
                                 M.MNAME,
                                 Y.MEMO,
                                 TO_DATE(:in_fr_date,'YYYYMMDD')    AS FR_DATE,
                                 TO_DATE(:in_to_date,'YYYYMMDD')   AS TO_DATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.SALE_OUT_AMT)    AS SALE_OUT_AMT,             
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( 
                                           SELECT  CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE, -- 당시 mcode 2였으나 현재 mcode 1에다가 테스트계정으로 바꾸어서 따로 추가함
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A 
                                          where   cust_code = 30490
                                          union all
                                          SELECT  CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                           AND   cust_code not in (select cust_code from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 특정 시점에 mcode 2로 추가된 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date > to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where memo like '%회원사구분 :대구 공공앱->테스트 회원사%'
                                                        and num = 1)
                                           and cust_code <> 30490
                                          UNION ALL
                                          SELECT CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                           UNION ALL
                                          SELECT CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                 '1' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                           and cust_code <> 30490
                                          AND   cust_code in (select x.cust_code from (select cust_code, memo from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 조회 시점에 mcode 1로 빠진 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date > to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where num = 1) x,
                                                        (select cust_code, memo from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 특정 시점에 mcode 2이었던 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date <= to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where num = 1) y
                                                        where x.cust_code = y.cust_code (+)
                                                        and x.memo like '%회원사구분 :대구 공공앱->테스트 회원사%'
                                                        and (y.memo is null or y.memo not like '%회원사구분 :대구 공공앱->테스트 회원사%'))) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO,                      
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.SALE_OUT_AMT)      AS SALE_OUT_AMT   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                               
                                                                           A.MEMO,                                 
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS SALE_OUT_AMT  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.logno <> '1226512'
                                                                  --and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           A.MEMO 
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,                                 
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS SALE_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                               
                                                                                   ( SELECT MEMO
                                                                                          FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                          WHERE C.LOGNO = A.LOGNO 
                                                                                          AND   C.LOG_GBN = '1')as MEMO,                                 
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A
                                                                          WHERE    A.LOG_GBN       = '3' and a.logno = 685327 -- in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo like '달서구 안심식당 인증이벤트')
                                                                          AND      CASE WHEN A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO
                                                                  UNION ALL
                                                                    SELECT APP_CUST_CODE, 
                                                                            LOGNO,
                                                                            MEMO ,
                                                                            0   AS IN_CNT  ,
                                                                            0   AS IN_AMT  ,
                                                                            0   AS ORDER_IN_CNT  ,
                                                                            0   AS ORDER_IN_AMT  ,
                                                                            0   AS SALE_IN_CNT  ,
                                                                            0   AS SALE_IN_AMT  ,
                                                                            SUM(ORDER_OUT_AMT)       AS ORDER_OUT_AMT  ,
                                                                            SUM(SALE_OUT_AMT)       AS SALE_OUT_AMT  ,
                                                                            SUM(NVL(OUT_AMT,0))    AS OUT_AMT     
                                                                     FROM ( 
                                                                        SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                ( SELECT MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN A
                                                                                  WHERE A.LOGNO = B.LOGNO 
                                                                                  AND   A.LOG_GBN = '1') AS MEMO ,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                CASE WHEN ORDER_NO IS NOT NULL THEN NVL(B.CHARGE_AMT,0) ELSE 0 END AS ORDER_OUT_AMT  ,
                                                                                CASE WHEN ORDER_NO IS NULL THEN NVL(B.CHARGE_AMT,0) ELSE 0 END     AS SALE_OUT_AMT  ,
                                                                                NVL(B.CHARGE_AMT,0)                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN B 
                                                                      WHERE     B.LOG_GBN = '3' --and b.memo like '%(선입/선출차감)'
                                                                      --and case when b.log_date > to_date(:the_time,'YYYYMMDDHH24MISS') then b.memo else '1' end <> '회원탈퇴, (선입/선출차감)'
                                                                      AND       CASE WHEN B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                                      )
                                                                      GROUP BY  APP_CUST_CODE, 
                                                                                LOGNO,
                                                                                MEMO   ) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO  ) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MEMO
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Mileage/getSaleMileageInOut : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 관리앱 마일리지(판매) 선입선출 대장, 대구로 통계(회계) v2
        /// </summary>
        /// <remarks>
        /// (이전테이블 조회)<br />
        /// sale_gbn 판매구분 <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지
        /// </remarks>
        [HttpGet("getSaleMileageInOut2")]
        public async Task<IActionResult> getSaleMileageInOut2(string date_begin, string date_end, int mcode, string sale_gbn, string cust_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();	// Object 타입으로 list 선언 (쿼리 결과물 담아서 리턴해주는 용도)

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";	// 에러코드
                Rmsg = "조회 기간을 설정해 주세요.";   // 에러메시지

                // return Ok <= 외부로 리턴해줄 때 Ok라고 적고 보내주는 것들 나열해주면 된다고 함.
                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_sale_gbn", sale_gbn);
                param.Add("in_cust_gbn", cust_gbn);

                string sql = @"
                                 SELECT  /*+ use_hash(X Y) no_merge(X) no_merge(Y) */    M.MCODE,
                                 M.MNAME,
                                 Y.MEMO,
                                 y.gbn,
                                 TO_DATE(:in_fr_date,'YYYYMMDD')    AS FR_DATE,
                                 TO_DATE(:in_to_date,'YYYYMMDD')   AS TO_DATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.TAXI_IN_CNT)     AS TAXI_IN_CNT,
                                 SUM(Y.TAXI_IN_AMT)     AS TAXI_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.TAXI_OUT_AMT)    AS TAXI_OUT_AMT,             
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( 
                                           SELECT  CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE, -- 당시 mcode 2였으나 현재 mcode 1에다가 테스트계정으로 바꾸어서 따로 추가함
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A 
                                          where   cust_code = 30490
                                          union all
                                          SELECT  CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                           AND   cust_code not in (select cust_code from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 특정 시점에 mcode 2로 추가된 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date > to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where memo like '%회원사구분 :대구 공공앱->테스트 회원사%'
                                                        and num = 1)
                                           and cust_code <> 30490
                                          UNION ALL
                                          SELECT CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END
                                           UNION ALL
                                          SELECT CASE WHEN :in_mcode = 0 THEN A.MCODE ELSE :in_mcode END MCODE,
                                                 '1' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                           and cust_code <> 30490
                                          AND   cust_code in (select x.cust_code from (select cust_code, memo from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 조회 시점에 mcode 1로 빠진 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date > to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where num = 1) x,
                                                        (select cust_code, memo from (select cust_code, memo,
                                                        row_number() over (partition by cust_code order by hist_date desc) as num
                                                        from app_customer_hist -- 특정 시점에 mcode 2이었던 회원
                                                        where memo like '%회원사구분 :%'
                                                        and hist_date <= to_date('20220224092010','YYYYMMDDHH24MISS'))
                                                        where num = 1) y
                                                        where x.cust_code = y.cust_code (+)
                                                        and x.memo like '%회원사구분 :대구 공공앱->테스트 회원사%'
                                                        and (y.memo is null or y.memo not like '%회원사구분 :대구 공공앱->테스트 회원사%'))) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO,  
                                                                           case when x.system_gbn = 'T' then 'T'
                                                                                when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                when x.system_gbn = 'D' and x.order_no is not null then 'D' end gbn,                
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.TAXI_IN_CNT)       AS TAXI_IN_CNT    ,
                                                                           SUM(X.TAXI_IN_AMT)       AS TAXI_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.TAXI_OUT_AMT)      AS TAXI_OUT_AMT   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                             
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end MEMO , 
                                                                           a.system_gbn, 
                                                                           a.order_no,                            
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN A.MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS TAXI_OUT_AMT  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.SYSTEM_GBN = 'D' AND A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.logno <> '1226512'
                                                                  --and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           a.system_gbn,
                                                                           a.order_no,
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,  
                                                                           SYSTEM_GBN, 
                                                                           order_no,                                
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )       AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)        AS SALE_IN_AMT  ,
                                                                           0                            AS TAXI_IN_CNT  ,
                                                                           0                            AS TAXI_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS TAXI_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                            
                                                                                   c.MEMO,
                                                                                   c.system_gbn,
                                                                                   c.order_no,                            
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A, 
                                                                                    ( SELECT logno, system_gbn, memo, order_no
                                                                                      FROM  APP_CUST_MILEAGE_REMAIN
                                                                                      WHERE logno = 685327 
                                                                                      AND   LOG_GBN = '1') C
                                                                          WHERE a.logno = c.logno
                                                                          and A.LOG_GBN       = '3' 
                                                                          and a.logno = 685327 -- in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo like '달서구 안심식당 인증이벤트')
                                                                          AND      CASE WHEN C.SYSTEM_GBN = 'D' AND A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO,
                                                                           system_gbn,
                                                                           order_no
                                                                  UNION ALL
                                                                    SELECT APP_CUST_CODE, 
                                                                            LOGNO,
                                                                            MEMO ,
                                                                            system_gbn,
                                                                            order_no,
                                                                            0   AS IN_CNT  ,
                                                                            0   AS IN_AMT  ,
                                                                            0   AS ORDER_IN_CNT  ,
                                                                            0   AS ORDER_IN_AMT  ,
                                                                            0   AS SALE_IN_CNT  ,
                                                                            0   AS SALE_IN_AMT  ,
                                                                            0   AS TAXI_IN_CNT  ,
                                                                            0   AS TAXI_IN_AMT  ,
                                                                            SUM(ORDER_OUT_AMT)       AS ORDER_OUT_AMT  ,
                                                                            SUM(TAXI_OUT_AMT)       AS TAXI_OUT_AMT  ,
                                                                            SUM(NVL(OUT_AMT,0))    AS OUT_AMT     
                                                                     FROM ( 
                                                                        SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                A.MEMO ,
                                                                                A.SYSTEM_GBN,
                                                                                A.order_no,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                0   AS TAXI_IN_CNT  ,
                                                                                0   AS TAXI_IN_AMT  ,
                                                                                CASE WHEN b.system_gbn = 'D' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END AS ORDER_OUT_AMT  ,
                                                                                CASE WHEN b.system_gbn = 'T' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END     AS TAXI_OUT_AMT  ,
                                                                                NVL(B.CHARGE_AMT,0)                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN B,
                                                                                (SELECT LOGNO,
                                                                                        SYSTEM_GBN, 
                                                                                        order_no,
                                                                                        case when system_gbn = 'T' then regexp_replace(memo,'[0-9|-]') else memo end MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN
                                                                                  WHERE LOG_GBN = '1') A
                                                                      WHERE B.LOGNO = A.LOGNO
                                                                      AND B.LOG_GBN = '3' --and b.memo like '%(선입/선출차감)'
                                                                      --and case when b.log_date > to_date(:the_time,'YYYYMMDDHH24MISS') then b.memo else '1' end <> '회원탈퇴, (선입/선출차감)'
                                                                      --AND       CASE WHEN A.SYSTEM_GBN = 'D' AND B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                
                                                                      )
                                                                      GROUP BY  APP_CUST_CODE, 
                                                                                LOGNO,
                                                                                MEMO,
                                                                                SYSTEM_GBN,
                                                                                order_no) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO,
                                                                               case when x.system_gbn = 'T' then 'T'
                                                                                    when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                    when x.system_gbn = 'D' and x.order_no is not null then 'D' end) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MEMO,
                                                   y.gbn
                                           ORDER BY y.gbn
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Mileage/getSaleMileageInOut2 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }

        /// <summary>
        /// 관리앱 마일리지(판매) 선입선출 대장, 대구로 통계(회계) v3
        /// </summary>
        /// <remarks>
        /// * 전일내역까지 조회가능 <br />
        /// sale_gbn 판매구분 : Y,N,% <br />
        /// cust_gbn 가입구분 : 1. 가입, 3. 해지, %. 전체 <br />
        /// [response] <br />
        /// 시작일 FR_DATE <br />
        /// 종료일 TO_DATE <br />
        /// 구분 GBN_NM <br />
        /// 판매내역 CUST_MILEAGE <br />
        /// 대장잔액 LOG_CUST_MILEAGE <br />
        /// 충전건수 IN_CNT <br />
        /// 충전합계 IN_AMT <br />
        /// 주문충전건수 ORDER_IN_CNT <br />
        /// 주문충전금액 ORDER_IN_AMT <br />
        /// 판매충전건수 SALE_IN_CNT <br />
        /// 판매충전금액 SALE_IN_AMT <br />
        /// 택시충전건수 TAXI_IN_CNT <br />
        /// 택시충전금액 TAXI_IN_AMT <br />
        /// 주문차감금액 ORDER_OUT_AMT <br />
        /// 택시차감금액(택시사용금액) TAXI_OUT_AMT1 <br />
        /// 택시차감금액(택시적립금반납액) TAXI_OUT_AMT2 <br />
        /// 차감합계 OUT_AMT <br />
        /// <br />
        /// </remarks>
        [HttpGet("getSaleMileageInOut3")]
        public async Task<IActionResult> getSaleMileageInOut3(string date_begin, string date_end, int mcode, string sale_gbn, string cust_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();	// Object 타입으로 list 선언 (쿼리 결과물 담아서 리턴해주는 용도)

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";	// 에러코드
                Rmsg = "조회 기간을 설정해 주세요.";   // 에러메시지

                // return Ok <= 외부로 리턴해줄 때 Ok라고 적고 보내주는 것들 나열해주면 된다고 함.
                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_mcode", mcode);
                param.Add("in_sale_gbn", sale_gbn);
                param.Add("in_cust_gbn", cust_gbn);

                string sql = @"
                                 SELECT  /*+ use_hash(X Y) no_merge(X) no_merge(Y) */    M.MCODE,
                                 M.MNAME,
                                 Y.MEMO,
                                 y.gbn,
                                 case when y.gbn = 'A' then '판매'
                                      when y.gbn = 'D' then '주문'
                                      when y.gbn = 'T' then '택시' end GBN_NM,
                                 TO_DATE(:in_fr_date,'YYYYMMDD')    AS FR_DATE,
                                 TO_DATE(:in_to_date,'YYYYMMDD')   AS TO_DATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.TAXI_IN_CNT)     AS TAXI_IN_CNT,
                                 SUM(Y.TAXI_IN_AMT)     AS TAXI_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.TAXI_OUT_AMT1)    AS TAXI_OUT_AMT1,   
                                 SUM(Y.TAXI_OUT_AMT2)    AS TAXI_OUT_AMT2,            
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( SELECT  :in_mcode MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = :in_mcode
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT :in_mcode MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = :in_mcode
                                           ) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO,  
                                                                           case when x.system_gbn = 'T' then 'T'
                                                                                when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                when x.system_gbn = 'D' and x.order_no is not null then 'D' end gbn,                
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.TAXI_IN_CNT)       AS TAXI_IN_CNT    ,
                                                                           SUM(X.TAXI_IN_AMT)       AS TAXI_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.TAXI_OUT_AMT1)      AS TAXI_OUT_AMT1   ,
                                                                           SUM(X.TAXI_OUT_AMT2)      AS TAXI_OUT_AMT2   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                             
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end MEMO , 
                                                                           a.system_gbn, 
                                                                           a.order_no,                            
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'D' and ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN 1 ELSE 0 END)                   AS TAXI_IN_CNT  ,
                                                                           SUM(CASE WHEN system_gbn = 'T' THEN A.MILEAGE_AMT ELSE 0 END)       AS TAXI_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS TAXI_OUT_AMT1  ,
                                                                           0                                                                    AS TAXI_OUT_AMT2  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN2 A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.SYSTEM_GBN = 'D' AND A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           a.system_gbn,
                                                                           a.order_no,
                                                                           case when a.system_gbn = 'T' then regexp_replace(a.memo,'[0-9|-]') else a.memo end
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,  
                                                                           SYSTEM_GBN, 
                                                                           order_no,                                
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )       AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)        AS SALE_IN_AMT  ,
                                                                           0                            AS TAXI_IN_CNT  ,
                                                                           0                            AS TAXI_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS TAXI_OUT_AMT1  ,
                                                                           0                            AS TAXI_OUT_AMT2  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   B.LOGNO ,                            
                                                                                   B.MEMO,
                                                                                   B.system_gbn,
                                                                                   B.order_no,                            
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN2 A, APP_CUST_MILEAGE_REMAIN2 B
                                                                          WHERE a.memo = to_char(b.logno)
                                                                          --AND a.memo not like '%(선입/선출차감)'
                                                                          and b.log_gbn = '1'
                                                                          AND      A.log_gbn = '3'
                                                                          AND      CASE WHEN B.SYSTEM_GBN = 'D' AND B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO,
                                                                           system_gbn,
                                                                           order_no
                                                                  UNION ALL
                                                                    SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                A.MEMO ,
                                                                                A.SYSTEM_GBN,
                                                                                A.order_no,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                0   AS TAXI_IN_CNT  ,
                                                                                0   AS TAXI_IN_AMT  ,
                                                                                SUM(CASE WHEN b.system_gbn = 'D' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                                SUM(CASE WHEN b.system_gbn = 'T' 
                                                                                         and b.memo like  '택시 [%] 에서 사용, (선입/선출차감)' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END)     AS TAXI_OUT_AMT1  ,
                                                                                SUM(CASE WHEN b.system_gbn = 'T'
                                                                                         and b.memo not like  '택시 [%] 에서 사용, (선입/선출차감)' THEN NVL(B.CHARGE_AMT,0) ELSE 0 END)     AS TAXI_OUT_AMT2  ,
                                                                                SUM(NVL(B.CHARGE_AMT,0))                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN2 B,
                                                                                (SELECT LOGNO,
                                                                                        SYSTEM_GBN, 
                                                                                        order_no,
                                                                                        case when system_gbn = 'T' then regexp_replace(memo,'[0-9|-]') else memo end MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN2
                                                                                  WHERE LOG_GBN = '1') A
                                                                      WHERE B.LOGNO = A.LOGNO
                                                                      AND B.LOG_GBN = '3'
                                                                      AND B.memo like '%(선입/선출차감)'
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')     
                                                                      GROUP BY  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                A.MEMO ,
                                                                                A.SYSTEM_GBN,
                                                                                A.order_no) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO,
                                                                               case when x.system_gbn = 'T' then 'T'
                                                                                    when x.system_gbn = 'D' and x.order_no is null then 'A'
                                                                                    when x.system_gbn = 'D' and x.order_no is not null then 'D' end) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MEMO,
                                                   y.gbn
                                           ORDER BY y.gbn
                                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
                await Utils.SaveErrorAsync("/Mileage/getSaleMileageInOut3 : Get", ex.Message);
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }



        /// <summary>
        /// 마일리지 통계 - 마일리지 선입선출 월별 통계(기간조건:CHARGE_TIME 정산일자)
        /// </summary>
        [HttpGet("getMileageInOutMonth")]
        public async Task<IActionResult> getMileageInOutMonth(string date_begin, string date_end, string cust_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_cust_gbn", cust_gbn);

                string sql = @"
                                 SELECT z.mdate, nvl(COUNT(*),0) AS COUNT,
                                 nvl(SUM(CUST_MILEAGE),0) AS SUM_CUST_MILEAGE,
                                 nvl(SUM(LOG_CUST_MILEAGE),0) AS SUM_LOG_CUST_MILEAGE,
                                 nvl(SUM(IN_CNT),0) AS SUM_IN_CNT,
                                 nvl(SUM(IN_AMT),0) AS SUM_IN_AMT,
                                 nvl(SUM(ORDER_IN_CNT),0) AS SUM_ORDER_IN_CNT,
                                 nvl(SUM(ORDER_IN_AMT),0) AS SUM_ORDER_IN_AMT,
                                 nvl(SUM(SALE_IN_CNT),0) AS SUM_SALE_IN_CNT,
                                 nvl(SUM(SALE_IN_AMT),0) AS SUM_SALE_IN_AMT,
                                 nvl(SUM(ORDER_OUT_AMT),0) AS SUM_ORDER_OUT_AMT,
                                 nvl(SUM(SALE_OUT_AMT),0) AS SUM_SALE_OUT_AMT,
                                 nvl(SUM(OUT_AMT),0) AS SUM_OUT_AMT,
                                 nvl(SUM(TERMINATE_AMT),0) AS SUM_TERMINATE_AMT
                                 FROM(  SELECT    M.MCODE, y.mdate,
                                                     M.MNAME,
                                                     X.CUST_GBN,
                                                     CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                     X.CUST_CODE,
                                                     SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                     X.CUST_MILEAGE,
                                                     Y.REMAIN_AMT AS LOG_CUST_MILEAGE, 
                                                     Y.IN_CNT, 
                                                     Y.IN_AMT,
                                                     Y.ORDER_IN_CNT,
                                                     Y.ORDER_IN_AMT,
                                                     Y.SALE_IN_CNT,
                                                     Y.SALE_IN_AMT,  
                                                     Y.ORDER_OUT_AMT,
                                                     Y.SALE_OUT_AMT,               
                                                     Y.OUT_AMT,
                                                     Q.TERMINATE_AMT
                                       FROM ( 
                                              SELECT  A.MCODE,
                                                      '1' AS CUST_GBN,
                                                      A.CUST_CODE,
                                                      A.CUST_NAME,
                                                      A.MILEAGE  AS CUST_MILEAGE
                                              FROM   APP_CUSTOMER A
                                              WHERE  CUST_ID_GBN <> 'Z'
                                              AND    A.MCODE   = 2
                                              AND   TEST_GBN = 'R' 
                                              UNION ALL
                                              SELECT A.MCODE,
                                                     '3' AS CUST_GBN,
                                                     A.CUST_CODE,
                                                     A.CUST_NAME,
                                                     A.MILEAGE  AS CUST_MILEAGE
                                              FROM   APP_CUSTOMER_DELETED A
                                              WHERE  CUST_ID_GBN <> 'Z'
                                              AND   TEST_GBN = 'R' 
                                              AND    A.MCODE   = 2
                                               ) X, 
                                            ( SELECT  d.APP_CUST_CODE, D.mdate,
                                                      SUM(NVL(D.IN_AMT,0) - NVL(D.OUT_AMT,0))   AS REMAIN_AMT, 
                                                      SUM(D.IN_CNT)         AS IN_CNT, 
                                                      SUM(D.IN_AMT)         AS IN_AMT,
                                                      SUM(D.ORDER_IN_CNT)   AS ORDER_IN_CNT,
                                                      SUM(D.ORDER_IN_AMT)   AS ORDER_IN_AMT,
                                                      SUM(D.SALE_IN_CNT)    AS SALE_IN_CNT,
                                                      SUM(D.SALE_IN_AMT)    AS SALE_IN_AMT,
                                                      SUM(D.ORDER_OUT_AMT)  AS ORDER_OUT_AMT,
                                                      SUM(D.SALE_OUT_AMT)   AS SALE_OUT_AMT,
                                                      SUM(D.OUT_AMT)       AS OUT_AMT
                                              FROM ( 
                                                         SELECT   /*+ full(A) parallel(A 4) */     
                                                                   A.APP_CUST_CODE, a.mdate,
                                                                   A.LOGNO ,                                                                
                                                                   SUM(1)                                         AS IN_CNT  ,
                                                                   SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS NOT NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO  IS NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END)    AS SALE_OUT_AMT  ,
                                                                   SUM(NVL(C.OUT_AMT,0))                                                AS OUT_AMT
                                                          FROM    (select aa.*, to_char(aa.log_date,'YYYYMM') as mdate from APP_CUST_MILEAGE_REMAIN aa
                                                          where  aa.LOG_GBN       = '1'
                                                          AND    aa.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS'))  A,--입금
                                                           ( SELECT    B.APP_CUST_CODE, to_char(b.charge_time,'YYYYMM') as mdate,
                                                                     B.LOGNO,
                                                                         SUM(B.CHARGE_AMT)              AS OUT_AMT 
                                                                  FROM    APP_CUST_MILEAGE_REMAIN B  
                                                                  WHERE  B.LOG_GBN = '3'
                                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  GROUP BY B.APP_CUST_CODE,  to_char(b.charge_time,'YYYYMM'),
                                                                           B.LOGNO ) C --출금
                                                          WHERE  A.APP_CUST_CODE = C.APP_CUST_CODE (+)
                                                          AND    A.LOGNO         = C.LOGNO         (+)
                                                          GROUP BY A.APP_CUST_CODE, a.mdate,
                                                                   A.LOGNO
                                                          UNION ALL 
                                                            SELECT APP_CUST_CODE, mdate,
                                                                   LOGNO ,                                 
                                                                   -1                           AS IN_CNT  ,
                                                                   SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                   0                            AS ORDER_IN_CNT  ,
                                                                   0                            AS ORDER_IN_AMT  ,
                                                                   -1                           AS SALE_IN_CNT  ,
                                                                   SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                   0                            AS ORDER_OUT_AMT  ,
                                                                   0                            AS SALE_OUT_AMT  ,
                                                                   0                            AS OUT_AMT 
                                                                   from(      
                                                                    SELECT A.APP_CUST_CODE, to_char(a.log_date,'YYYYMM') as mdate,
                                                                           A.LOGNO ,                               
                                                                           ( SELECT MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                  WHERE C.LOGNO = A.LOGNO 
                                                                                  AND   C.LOG_GBN = '1')as MEMO,                                 
                                                                           A.CHARGE_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')) a
                                                          GROUP BY A.APP_CUST_CODE, a.mdate,
                                                                   A.LOGNO ) D
                                                  GROUP BY d.APP_CUST_CODE, D.mdate ) Y,  MEMBERSHIP M,
                                                  (select ORI_REMAIN_AMT, MILEAGE_AMT AS TERMINATE_AMT, APP_CUST_CODE from app_cust_mileage_log
                                                     where memo like '%탈퇴%'
                                                     and to_char(log_date,'YYYYMMDD') >= '20210817') Q
                                               WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                               AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                               AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                               AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                               AND  X.MCODE  = M.MCODE
                                  ) Z group by z.mdate
                                  order by z.mdate
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 마일리지 통계 - 마일리지 선입선출 월별 통계 - 상세
        /// </summary>
        [HttpGet("getMileageInOutDay/{date_ym}")]
        public async Task<IActionResult> getMileageInOutDay(string date_begin, string date_end, string cust_gbn, string date_ym)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_ym))
            {
                Rcode = "01";
                Rmsg = "해당 월을 입력해주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_date_ym", date_ym);


                string sql = @"
                                 SELECT z.mdate, nvl(COUNT(*),0) AS COUNT,
                                 nvl(SUM(CUST_MILEAGE),0) AS SUM_CUST_MILEAGE,
                                 nvl(SUM(LOG_CUST_MILEAGE),0) AS SUM_LOG_CUST_MILEAGE,
                                 nvl(SUM(IN_CNT),0) AS SUM_IN_CNT,
                                 nvl(SUM(IN_AMT),0) AS SUM_IN_AMT,
                                 nvl(SUM(ORDER_IN_CNT),0) AS SUM_ORDER_IN_CNT,
                                 nvl(SUM(ORDER_IN_AMT),0) AS SUM_ORDER_IN_AMT,
                                 nvl(SUM(SALE_IN_CNT),0) AS SUM_SALE_IN_CNT,
                                 nvl(SUM(SALE_IN_AMT),0) AS SUM_SALE_IN_AMT,
                                 nvl(SUM(ORDER_OUT_AMT),0) AS SUM_ORDER_OUT_AMT,
                                 nvl(SUM(SALE_OUT_AMT),0) AS SUM_SALE_OUT_AMT,
                                 nvl(SUM(OUT_AMT),0) AS SUM_OUT_AMT,
                                 nvl(SUM(TERMINATE_AMT),0) AS SUM_TERMINATE_AMT
                                 FROM(  SELECT    M.MCODE, y.mdate,
                                                     M.MNAME,
                                                     X.CUST_GBN,
                                                     CASE WHEN X.CUST_GBN = '1' THEN '가입' ELSE '해지' END CUST_GBN_NM,
                                                     X.CUST_CODE,
                                                     SF_CHANGE_MASKING('NAME', X.CUST_NAME ) AS CUST_NAME,
                                                     X.CUST_MILEAGE,
                                                     Y.REMAIN_AMT AS LOG_CUST_MILEAGE, 
                                                     Y.IN_CNT, 
                                                     Y.IN_AMT,
                                                     Y.ORDER_IN_CNT,
                                                     Y.ORDER_IN_AMT,
                                                     Y.SALE_IN_CNT,
                                                     Y.SALE_IN_AMT,  
                                                     Y.ORDER_OUT_AMT,
                                                     Y.SALE_OUT_AMT,               
                                                     Y.OUT_AMT,
                                                     Q.TERMINATE_AMT
                                       FROM ( 
                                              SELECT  A.MCODE,
                                                      '1' AS CUST_GBN,
                                                      A.CUST_CODE,
                                                      A.CUST_NAME,
                                                      A.MILEAGE  AS CUST_MILEAGE
                                              FROM   APP_CUSTOMER A
                                              WHERE  CUST_ID_GBN <> 'Z'
                                              AND    A.MCODE   = 2
                                              AND   TEST_GBN = 'R' 
                                              UNION ALL
                                              SELECT A.MCODE,
                                                     '3' AS CUST_GBN,
                                                     A.CUST_CODE,
                                                     A.CUST_NAME,
                                                     A.MILEAGE  AS CUST_MILEAGE
                                              FROM   APP_CUSTOMER_DELETED A
                                              WHERE  CUST_ID_GBN <> 'Z'
                                              AND   TEST_GBN = 'R' 
                                              AND    A.MCODE   = 2
                                               ) X, 
                                            ( SELECT  d.APP_CUST_CODE, D.mdate,
                                                      SUM(NVL(D.IN_AMT,0) - NVL(D.OUT_AMT,0))   AS REMAIN_AMT, 
                                                      SUM(D.IN_CNT)         AS IN_CNT, 
                                                      SUM(D.IN_AMT)         AS IN_AMT,
                                                      SUM(D.ORDER_IN_CNT)   AS ORDER_IN_CNT,
                                                      SUM(D.ORDER_IN_AMT)   AS ORDER_IN_AMT,
                                                      SUM(D.SALE_IN_CNT)    AS SALE_IN_CNT,
                                                      SUM(D.SALE_IN_AMT)    AS SALE_IN_AMT,
                                                      SUM(D.ORDER_OUT_AMT)  AS ORDER_OUT_AMT,
                                                      SUM(D.SALE_OUT_AMT)   AS SALE_OUT_AMT,
                                                      SUM(D.OUT_AMT)       AS OUT_AMT
                                              FROM ( 
                                                         SELECT   /*+ full(A) parallel(A 4) */     
                                                                   A.APP_CUST_CODE, a.mdate,
                                                                   A.LOGNO ,                                                                
                                                                   SUM(1)                                         AS IN_CNT  ,
                                                                   SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO IS NOT NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END) AS ORDER_OUT_AMT  ,
                                                                   SUM(CASE WHEN ORDER_NO  IS NULL THEN NVL(C.OUT_AMT,0) ELSE 0 END)    AS SALE_OUT_AMT  ,
                                                                   SUM(NVL(C.OUT_AMT,0))                                                AS OUT_AMT
                                                          FROM    (select aa.*, to_char(aa.log_date,'YYYYMMDD') as mdate from APP_CUST_MILEAGE_REMAIN aa
                                                          where  aa.LOG_GBN       = '1'
                                                          AND    aa.LOG_DATE BETWEEN TO_DATE(:in_date_ym || '01 000000', 'YYYYMMDD HH24MISS') AND  last_day(TO_DATE(:in_date_ym || '01 235959', 'YYYYMMDD HH24MISS'))
                                                          AND    aa.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS'))  A,--입금
                                                           ( SELECT    B.APP_CUST_CODE, to_char(b.charge_time,'YYYYMMDD') as mdate,
                                                                     B.LOGNO,
                                                                         SUM(B.CHARGE_AMT)              AS OUT_AMT 
                                                                  FROM    APP_CUST_MILEAGE_REMAIN B  
                                                                  WHERE  B.LOG_GBN = '3'
                                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_date_ym || '01 000000', 'YYYYMMDD HH24MISS') AND  last_day(TO_DATE(:in_date_ym || '01 235959', 'YYYYMMDD HH24MISS'))
                                                                  AND    B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  GROUP BY B.APP_CUST_CODE,  to_char(b.charge_time,'YYYYMMDD'),
                                                                           B.LOGNO ) C --출금
                                                          WHERE  A.APP_CUST_CODE = C.APP_CUST_CODE (+)
                                                          AND    A.LOGNO         = C.LOGNO         (+)
                                                          GROUP BY A.APP_CUST_CODE, a.mdate,
                                                                   A.LOGNO
                                                          UNION ALL 
                                                            SELECT APP_CUST_CODE, mdate,
                                                                   LOGNO ,                                 
                                                                   -1                           AS IN_CNT  ,
                                                                   SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                   0                            AS ORDER_IN_CNT  ,
                                                                   0                            AS ORDER_IN_AMT  ,
                                                                   -1                           AS SALE_IN_CNT  ,
                                                                   SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                   0                            AS ORDER_OUT_AMT  ,
                                                                   0                            AS SALE_OUT_AMT  ,
                                                                   0                            AS OUT_AMT 
                                                                   from(      
                                                                    SELECT A.APP_CUST_CODE, to_char(a.log_date,'YYYYMMDD') as mdate,
                                                                           A.LOGNO ,                               
                                                                           ( SELECT MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                  WHERE C.LOGNO = A.LOGNO 
                                                                                  AND   C.LOG_GBN = '1')as MEMO,                                 
                                                                           A.CHARGE_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_date_ym || '01 000000', 'YYYYMMDD HH24MISS') AND  last_day(TO_DATE(:in_date_ym || '01 235959', 'YYYYMMDD HH24MISS'))
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')) a
                                                          GROUP BY A.APP_CUST_CODE, a.mdate,
                                                                   A.LOGNO ) D
                                                  GROUP BY d.APP_CUST_CODE, D.mdate ) Y,  MEMBERSHIP M,
                                                  (select ORI_REMAIN_AMT, MILEAGE_AMT AS TERMINATE_AMT, APP_CUST_CODE from app_cust_mileage_log
                                                     where memo like '%탈퇴%'
                                                     and to_char(log_date,'YYYYMMDD') >= '20210817'
                                                     order by log_date desc) Q
                                               WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                               AND X.CUST_CODE = Q.APP_CUST_CODE(+)
                                               AND  X.CUST_GBN  LIKE :in_cust_gbn 
                                               AND  ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                               AND  X.MCODE  = M.MCODE
                                  ) Z group by z.mdate
                                  order by z.mdate
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }

            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }




        /// <summary>
        /// 마일리지 통계 - 판매마일리지 선입선출 월별 통계(기간조건:CHARGE_TIME 정산일자)
        /// </summary>
        [HttpGet("getSaleMileageInOutMonth")]
        public async Task<IActionResult> getSaleMileageInOutMonth(string date_begin, string date_end, string cust_gbn, string sale_gbn)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_begin) || string.IsNullOrEmpty(date_end))
            {
                Rcode = "01";
                Rmsg = "조회 기간을 설정해 주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_sale_gbn", sale_gbn);

                string sql = @"
                                SELECT    M.MCODE,
                                 M.MNAME,
                                 Y.MDATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.SALE_OUT_AMT)    AS SALE_OUT_AMT,             
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( 
                                          SELECT  A.MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = 2
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT A.MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = 2
                                           ) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO, 
                                                                           X.MDATE,                     
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.SALE_OUT_AMT)      AS SALE_OUT_AMT   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                               
                                                                           A.MEMO,    
                                                                           TO_CHAR(A.LOG_DATE,'YYYYMM') AS MDATE,                             
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS SALE_OUT_AMT  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  --and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           A.MEMO,
                                                                           TO_CHAR(A.LOG_DATE,'YYYYMM') 
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,  
                                                                           MDATE,                               
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS SALE_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                               
                                                                                   ( SELECT MEMO
                                                                                          FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                          WHERE C.LOGNO = A.LOGNO 
                                                                                          AND   C.LOG_GBN = '1')as MEMO,  
                                                                                   TO_CHAR(A.LOG_DATE,'YYYYMM') AS MDATE,
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A
                                                                          WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                                          AND      CASE WHEN A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO,
                                                                           MDATE
                                                                  UNION ALL
                                                                    SELECT APP_CUST_CODE, 
                                                                            LOGNO,
                                                                            MEMO ,
                                                                            MDATE,
                                                                            0   AS IN_CNT  ,
                                                                            0   AS IN_AMT  ,
                                                                            0   AS ORDER_IN_CNT  ,
                                                                            0   AS ORDER_IN_AMT  ,
                                                                            0   AS SALE_IN_CNT  ,
                                                                            0   AS SALE_IN_AMT  ,
                                                                            SUM(ORDER_OUT_AMT)       AS ORDER_OUT_AMT  ,
                                                                            SUM(SALE_OUT_AMT)       AS SALE_OUT_AMT  ,
                                                                            SUM(NVL(OUT_AMT,0))    AS OUT_AMT     
                                                                     FROM ( 
                                                                        SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                ( SELECT MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN A
                                                                                  WHERE A.LOGNO = B.LOGNO 
                                                                                  AND   A.LOG_GBN = '1') AS MEMO ,
                                                                                TO_CHAR(B.CHARGE_TIME,'YYYYMM') AS MDATE,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                CASE WHEN ORDER_NO IS NOT NULL THEN NVL(B.CHARGE_AMT,0) ELSE 0 END AS ORDER_OUT_AMT  ,
                                                                                CASE WHEN ORDER_NO IS NULL THEN NVL(B.CHARGE_AMT,0) ELSE 0 END     AS SALE_OUT_AMT  ,
                                                                                NVL(B.CHARGE_AMT,0)                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN B 
                                                                      WHERE     B.LOG_GBN = '3' and b.memo like '%(선입/선출차감)'
                                                                      AND       CASE WHEN B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                    
                                                                      )
                                                                      GROUP BY  APP_CUST_CODE, 
                                                                                LOGNO,
                                                                                MEMO,
                                                                                MDATE  ) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO,
                                                                               X.MDATE  ) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MDATE
                                          ORDER BY Y.MDATE
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }


        /// <summary>
        /// 마일리지 통계 - 판매마일리지 선입선출 월별 통계 - 상세
        /// </summary>
        [HttpGet("getSaleMileageInOutDay/{date_ym}")]
        public async Task<IActionResult> getSaleMileageInOutDay(string date_begin, string date_end, string cust_gbn, string sale_gbn, string date_ym)
        {
            string Rcode = string.Empty;
            string Rmsg = string.Empty;
            List<object> items = new List<object>();

            if (string.IsNullOrEmpty(date_ym))
            {
                Rcode = "01";
                Rmsg = "해당 월을 입력해주세요.";

                return Ok(new { code = Rcode, msg = Rmsg, data = items });
            }

            try
            {
                using IDbConnection db = new OracleConnection(Utils.oracleConnectString);
                db.Open();
                DynamicParameters param = new DynamicParameters();
                param.Add("in_fr_date", date_begin);
                param.Add("in_to_date", date_end);
                param.Add("in_cust_gbn", cust_gbn);
                param.Add("in_sale_gbn", sale_gbn);
                param.Add("in_date_ym", date_ym);


                string sql = @"
                                SELECT    M.MCODE,
                                 M.MNAME,
                                 Y.MDATE,
                                 SUM(Y.REMAIN_AMT)     AS LOG_CUST_MILEAGE, 
                                 SUM(Y.IN_CNT)          AS IN_CNT , 
                                 SUM(Y.IN_AMT)          AS IN_AMT,
                                 SUM(Y.ORDER_IN_CNT)    AS ORDER_IN_CNT,
                                 SUM(Y.ORDER_IN_AMT)    AS ORDER_IN_AMT,
                                 SUM(Y.SALE_IN_CNT)     AS SALE_IN_CNT,
                                 SUM(Y.SALE_IN_AMT)     AS SALE_IN_AMT,
                                 SUM(Y.ORDER_OUT_AMT)   AS ORDER_OUT_AMT,
                                 SUM(Y.SALE_OUT_AMT)    AS SALE_OUT_AMT,             
                                 SUM(Y.OUT_AMT)         AS OUT_AMT
                                   FROM ( 
                                          SELECT  A.MCODE,
                                                  '1' AS CUST_GBN,
                                                  A.CUST_CODE,
                                                  A.CUST_NAME,
                                                  A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND    A.MCODE   = 2
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          UNION ALL
                                          SELECT A.MCODE,
                                                 '3' AS CUST_GBN,
                                                 A.CUST_CODE,
                                                 A.CUST_NAME,
                                                 A.MILEAGE  AS CUST_MILEAGE
                                          FROM   APP_CUSTOMER_DELETED A
                                          WHERE  CUST_ID_GBN <> 'Z'
                                          AND   TEST_GBN = 'R' 
                                           AND   INSERT_DATE >= TO_DATE('2021080917','YYYYMMDDHH24')  
                                          AND    A.MCODE   = 2
                                           ) X, 
                                                ( SELECT                   X.APP_CUST_CODE, 
                                                                           X.LOGNO ,                               
                                                                           X.MEMO, 
                                                                           X.MDATE,                     
                                                                           SUM(NVL(X.IN_AMT,0) - NVL(X.OUT_AMT,0))   AS REMAIN_AMT,            
                                                                           SUM(X.IN_CNT)            AS IN_CNT  ,
                                                                           SUM(X.IN_AMT )           AS IN_AMT  ,
                                                                           SUM(X.ORDER_IN_CNT)      AS ORDER_IN_CNT  ,
                                                                           SUM(X.ORDER_IN_AMT)      AS ORDER_IN_AMT   ,
                                                                           SUM(X.SALE_IN_CNT)       AS SALE_IN_CNT    ,
                                                                           SUM(X.SALE_IN_AMT)       AS SALE_IN_AMT    ,
                                                                           SUM(X.ORDER_OUT_AMT)     AS ORDER_OUT_AMT  ,
                                                                           SUM(X.SALE_OUT_AMT)      AS SALE_OUT_AMT   ,
                                                                           SUM(X.OUT_AMT)           AS OUT_AMT                
                                                                 FROM (
                                                                   SELECT   /*+ full(A) parallel(A 4) */     
                                                                           A.APP_CUST_CODE, 
                                                                           A.LOGNO ,                               
                                                                           A.MEMO,    
                                                                           TO_CHAR(A.LOG_DATE,'YYYYMMDD') AS MDATE,                             
                                                                           SUM(1)                                          AS IN_CNT  ,
                                                                           SUM(A.MILEAGE_AMT )                             AS IN_AMT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN 1 ELSE 0 END)               AS ORDER_IN_CNT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NOT NULL THEN A.MILEAGE_AMT ELSE 0 END)   AS ORDER_IN_AMT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NULL THEN 1 ELSE 0 END)                   AS SALE_IN_CNT  ,
                                                                           SUM(CASE WHEN ORDER_NO IS  NULL THEN A.MILEAGE_AMT ELSE 0 END)       AS SALE_IN_AMT  ,
                                                                           0                                                                    AS ORDER_OUT_AMT  ,
                                                                           0                                                                    AS SALE_OUT_AMT  ,
                                                                           0                                                                    AS OUT_AMT
                                                                  FROM     APP_CUST_MILEAGE_REMAIN A
                                                                  WHERE    A.LOG_GBN       = '1'
                                                                  AND      CASE WHEN A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_date_ym||'01 000000', 'YYYYMMDD HH24MISS') AND  last_day(TO_DATE(:in_date_ym||'01 235959', 'YYYYMMDD HH24MISS'))
                                                                  AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                  --and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                  --and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                  GROUP BY A.APP_CUST_CODE, 
                                                                           A.LOGNO,
                                                                           A.MEMO,
                                                                           TO_CHAR(A.LOG_DATE,'YYYYMMDD') 
                                                                  UNION ALL 
                                                                    SELECT APP_CUST_CODE, 
                                                                           LOGNO ,                               
                                                                           MEMO,  
                                                                           MDATE,                               
                                                                           -1                           AS IN_CNT  ,
                                                                           SUM(-1 * charge_amt )     AS IN_AMT  ,
                                                                           0                            AS ORDER_IN_CNT  ,
                                                                           0                            AS ORDER_IN_AMT  ,
                                                                           -1                           AS SALE_IN_CNT  ,
                                                                           SUM(-1 * charge_amt)       AS SALE_IN_AMT  ,
                                                                           0                            AS ORDER_OUT_AMT  ,
                                                                           0                            AS SALE_OUT_AMT  ,
                                                                           0                            AS OUT_AMT 
                                                                           from(      
                                                                            SELECT A.APP_CUST_CODE, 
                                                                                   A.LOGNO ,                               
                                                                                   ( SELECT MEMO
                                                                                          FROM  APP_CUST_MILEAGE_REMAIN C
                                                                                          WHERE C.LOGNO = A.LOGNO 
                                                                                          AND   C.LOG_GBN = '1')as MEMO,  
                                                                                   TO_CHAR(A.LOG_DATE,'YYYYMMDD') AS MDATE,
                                                                                   A.CHARGE_AMT
                                                                          FROM     APP_CUST_MILEAGE_REMAIN A
                                                                          WHERE    A.LOG_GBN       = '3' and a.logno in (select logno from APP_CUST_MILEAGE_REMAIN where log_gbn = '3' and memo not like '%(선입/선출차감)')
                                                                          AND      CASE WHEN A.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_date_ym||'01 000000', 'YYYYMMDD HH24MISS') AND  last_day(TO_DATE(:in_date_ym||'01 235959', 'YYYYMMDD HH24MISS'))
                                                                          AND      A.LOG_DATE BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')
                                                                          and      a.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                          and      a.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')   
                                                                          )
                                                                  GROUP BY APP_CUST_CODE, 
                                                                           LOGNO,
                                                                           MEMO,
                                                                           MDATE
                                                                  UNION ALL
                                                                    SELECT APP_CUST_CODE, 
                                                                            LOGNO,
                                                                            MEMO ,
                                                                            MDATE,
                                                                            0   AS IN_CNT  ,
                                                                            0   AS IN_AMT  ,
                                                                            0   AS ORDER_IN_CNT  ,
                                                                            0   AS ORDER_IN_AMT  ,
                                                                            0   AS SALE_IN_CNT  ,
                                                                            0   AS SALE_IN_AMT  ,
                                                                            SUM(ORDER_OUT_AMT)       AS ORDER_OUT_AMT  ,
                                                                            SUM(SALE_OUT_AMT)       AS SALE_OUT_AMT  ,
                                                                            SUM(NVL(OUT_AMT,0))    AS OUT_AMT     
                                                                     FROM ( 
                                                                        SELECT  B.APP_CUST_CODE, 
                                                                                B.LOGNO,
                                                                                ( SELECT MEMO
                                                                                  FROM  APP_CUST_MILEAGE_REMAIN A
                                                                                  WHERE A.LOGNO = B.LOGNO 
                                                                                  AND   A.LOG_GBN = '1') AS MEMO ,
                                                                                TO_CHAR(B.CHARGE_TIME,'YYYYMMDD') AS MDATE,
                                                                                0   AS IN_CNT  ,
                                                                                0   AS IN_AMT  ,
                                                                                0   AS ORDER_IN_CNT  ,
                                                                                0   AS ORDER_IN_AMT  ,
                                                                                0   AS SALE_IN_CNT  ,
                                                                                0   AS SALE_IN_AMT  ,
                                                                                CASE WHEN ORDER_NO IS NOT NULL THEN NVL(B.CHARGE_AMT,0) ELSE 0 END AS ORDER_OUT_AMT  ,
                                                                                CASE WHEN ORDER_NO IS NULL THEN NVL(B.CHARGE_AMT,0) ELSE 0 END     AS SALE_OUT_AMT  ,
                                                                                NVL(B.CHARGE_AMT,0)                                                AS OUT_AMT
                                                                      FROM      APP_CUST_MILEAGE_REMAIN B 
                                                                      WHERE     B.LOG_GBN = '3' and b.memo like '%(선입/선출차감)'
                                                                      AND       CASE WHEN B.ORDER_NO  IS NULL THEN 'Y' ELSE 'N' END LIKE :in_sale_gbn
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_date_ym||'01 000000', 'YYYYMMDD HH24MISS') AND  last_day(TO_DATE(:in_date_ym||'01 235959', 'YYYYMMDD HH24MISS'))
                                                                      AND       B.CHARGE_TIME BETWEEN TO_DATE(:in_fr_date||' 000000', 'YYYYMMDD HH24MISS') AND  TO_DATE(:in_to_date||' 235959', 'YYYYMMDD HH24MISS')   
                                                                      and      b.LOG_DATE >= to_date('2021080917','YYYYMMDDHH24')    
                                                                      and      b.CHARGE_TIME >= to_date('2021080917','YYYYMMDDHH24')                                    
                                                                      )
                                                                      GROUP BY  APP_CUST_CODE, 
                                                                                LOGNO,
                                                                                MEMO,
                                                                                MDATE  ) X 
                                                                   GROUP BY    X.APP_CUST_CODE, 
                                                                               X.LOGNO ,                               
                                                                               X.MEMO,
                                                                               X.MDATE  ) Y,  MEMBERSHIP M    
                                           WHERE  X.CUST_CODE = Y.APP_CUST_CODE 
                                           AND    X.CUST_GBN  LIKE :in_cust_gbn 
                                           AND    ( Y.IN_AMT <> 0 OR Y.OUT_AMT <> 0 )
                                           AND    X.MCODE    = M.MCODE 
                                          GROUP BY M.MCODE,
                                                   M.MNAME,
                                                   Y.MDATE
                                          ORDER BY Y.MDATE
                ";

                var temp = await db.QueryAsync(sql, param, commandType: CommandType.Text);

                items = temp.ToList();

                db.Close();

                Rcode = "00";
                Rmsg = "성공";
            }
            catch (Exception ex)
            {

                Rcode = "01";
                Rmsg = ex.Message;
            }



            return Ok(new { code = Rcode, msg = Rmsg, data = items });
        }
    }
}
