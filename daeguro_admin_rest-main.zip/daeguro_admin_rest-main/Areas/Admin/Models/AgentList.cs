﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class AgentList
    {
        public string ccCode { get; set; }
        public string ccName { get; set; }
        public string cLevel { get; set; }
        public string ddd { get; set; }
        public string telNo { get; set; }
        public string faxNo { get; set; }
        public string regNo { get; set; }
        public string useGbn { get; set; }
        public string remainAmt { get; set; }
        public string addr { get; set; }
        public string owner { get; set; }
    }
}
