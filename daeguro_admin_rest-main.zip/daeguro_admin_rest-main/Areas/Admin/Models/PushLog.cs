﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class PushLog
    {
        /// <summary>
        /// PK값 (put only)
        /// </summary>
        //public string push_cd { get; set; }
        /// <summary>
        /// 발송 시작일시
        /// </summary>
        public string st_date { get; set; }

        /// <summary>
        /// 로그 메시지
        /// </summary>
        public string txt { get; set; }
        ///// <summary>
        ///// 발송 일시
        ///// </summary>
        //public string send_date { get; set; }
        ///// <summary>
        ///// 회원코드
        ///// </summary>
        //public string cust_code { get; set; }
        ///// <summary>
        ///// 전화번호
        ///// </summary>
        //public string cust_telno { get; set; }
        ///// <summary>
        ///// 처리 결과 메시지
        ///// </summary>
        //public string send_result { get; set; }
        ///// <summary>
        ///// 푸시 성공 여부
        ///// </summary>
        //public string succesed_yn { get; set; }

        //public override string ToString()
        //{
        //    return $"전송일시: {this.send_date}/ 회원코드: {this.cust_code}/ 전화번호: {this.cust_telno}/ 성공여부: {this.succesed_yn}/ 결과 메시지: {this.send_result}";
        //}
    }
}

