﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OrderUpdate
    {
        public string orderNo { get; set; }
        public string status { get; set; }
        public string riderInfo { get; set; }
        public string modCode { get; set; }
        public string modName { get; set; }
        public string cancelCode { get; set; }
        public string cancelReason { get; set; }
    }
}
