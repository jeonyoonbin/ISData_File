﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class NoticeEmList
    {
        public string seq { get; set; }
        public string use { get; set; }
        public string title { get; set; }
        public string device_gbn { get; set; }
        public string android_ver { get; set; }
        public string android_min { get; set; }
        public string ios_ver { get; set; }
        public string ios_min { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class NoticeEmDetail
    {
        public string seq { get; set; }
        public string use { get; set; }
        public string title { get; set; }
        public string contents { get; set; }
        public string url { get; set; }
        public string img_url { get; set; }
        public string device_gbn { get; set; }
        public string android_ver { get; set; }
        public string android_min { get; set; }
        public string ios_ver { get; set; }
        public string ios_min { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class NoticeEm
    {
        public string seq { get; set; }
        public string use { get; set; }
        public string title { get; set; }
        public string contents { get; set; }
        public string url { get; set; }
        public string device_gbn { get; set; }
        public string android_ver { get; set; }
        public string android_min { get; set; }
        public string ios_ver { get; set; }
        public string ios_min { get; set; }
        public string ucode { get; set; }
    }

    public class NoticePayEm
    {
        public string seq { get; set; }
        //public string disorder_divice_gbn { get; set; }
        public string card_yn { get; set; }
        public string card_msg { get; set; }
        public string happy_pay_yn { get; set; }
        public string happy_pay_msg { get; set; }
        public string kakao_yn { get; set; }
        public string kakao_msg { get; set; }
        public string naver_yn { get; set; }
        public string naver_msg { get; set; }
        public string samsung_yn   { get; set; }
        public string samsung_msg   { get; set; }
        public string meet_cash_yn { get; set; }
        public string meet_cash_msg { get; set; }
        public string meet_card_yn { get; set; }
        public string meet_card_msg { get; set; }
        public string zero_pay_yn { get; set; }
        public string zero_pay_msg { get; set; }
        public string onnuri_vc_yn { get; set; }
        public string onnuri_vc_msg { get; set; }
        public string toss_yn { get; set; }
        public string toss_msg { get; set; }
        public string apple_pay_yn { get; set; }
        public string apple_pay_msg { get; set; }
        public string shinhan_pg_yn { get; set; }
        public string shinhan_pg_msg { get; set; }
        public string child_card_yn { get; set; }
        public string child_card_msg { get; set; }
        public string non_mem_card_yn { get; set; }
        public string non_mem_card_msg { get; set; }
        public string ucode { get; set; }
    }

    public class NoticePayEmDetail
    {
        public string seq { get; set; }
        public string disorder_divice_gbn { get; set; }
        public string card_yn { get; set; }
        public string card_msg { get; set; }
        public string happy_pay_yn { get; set; }
        public string happy_pay_msg { get; set; }
        public string kakao_yn { get; set; }
        public string kakao_msg { get; set; }
        public string naver_yn { get; set; }
        public string naver_msg { get; set; }
        public string samsung_yn { get; set; }
        public string samsung_msg { get; set; }
        public string meet_cash_yn { get; set; }
        public string meet_cash_msg { get; set; }
        public string meet_card_yn { get; set; }
        public string meet_card_msg { get; set; }
        public string zero_pay_yn { get; set; }
        public string zero_pay_msg { get; set; }
        public string onnuri_vc_yn { get; set; }
        public string onnuri_vc_msg { get; set; }
        public string toss_yn { get; set; }
        public string toss_msg { get; set; }
        public string apple_pay_yn { get; set; }
        public string apple_pay_msg { get; set; }
        public string shinhan_pg_yn { get; set; }
        public string shinhan_pg_msg { get; set; }
        public string child_card_yn { get; set; }
        public string child_card_msg { get; set; }
        public string non_mem_card_yn { get; set; }
        public string non_mem_card_msg { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
