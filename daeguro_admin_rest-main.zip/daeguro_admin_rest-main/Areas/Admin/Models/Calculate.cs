﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ChargeGbn
    {
        public string charge_gbn { get; set; }
        public string charge_name { get; set; }
        public string sort_seq { get; set; }
    }

    public class Calculate
    {
        public string orderYm { get; set; }
        public string mcode { get; set; }
        public string cccode { get; set; }
        public string shopCd { get; set; }
        public string shopName { get; set; }
        public string issymd { get; set; }
        public string taxNo { get; set; }
        public string taxGbn { get; set; }
        public string saleGbn { get; set; }
        public string supamt { get; set; }
        public string vatamt { get; set; }
        public string amt { get; set; }
        public string memo { get; set; }
        public string prtYn { get; set; }
        public string prtDate { get; set; }
        public string prtGbn { get; set; }
        public string etaxYn { get; set; }
        public string reqDate { get; set; }
        public string status { get; set; }
        public string rtnMsg { get; set; }
        public string rtnDate { get; set; }
        public string isrtUcode { get; set; }
        public string isrtDate { get; set; }
        public string modUcode { get; set; }
        public string modDate { get; set; }
        public string canReason { get; set; }
        public string receiptId { get; set; }
        public string etaxSeq { get; set; }
        public string taxAcc { get; set; }
        public string feeYm { get; set; }
        public string fdiaGbn { get; set; }
        public string apiComGbn { get; set; }
        public string cret_yn { get; set; }
        public string mName { get; set; }
        public string mainCcname { get; set; }
        public string regNo { get; set; }
        public string issCdStatus { get; set; }
    }
    
}
