﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ResponseNaverGeocode
    {
        public string status { get; set; }
        public Meta meta { get; set; }
        public List<Address> addresses { get; set; }
        public string errorMessage { get; set; }
    }
    public class ResponseNaverReverseGeocode
    {
        public Status status { get; set; }
        public List<Result> results { get; set; }
    }

    #region Geocode
    public class Meta
    {
        public int totalCount { get; set; }
        public int page { get; set; }
        public int count { get; set; }
    }
    public class AddressElement
    {
        public List<string> types { get; set; }
        public string longName { get; set; }
        public string shortName { get; set; }
        public string code { get; set; }

    }
    public class Address
    {
        public string roadAddress { get; set; }
        public string jibunAddress { get; set; }
        public string englishAddress { get; set; }
        public List<AddressElement> addressElements { get; set; }
        public string x { get; set; }
        public string y { get; set; }
        public double distance { get; set; }
    }
    #endregion

    #region ReverseGeocode
    public class Status
    {
        public int code { get; set; }
        public string name { get; set; }
        public string message { get; set; }
    }
    public class Code
    {
        public string id { get; set; }
        public string type { get; set; }
        public string mapping { get; set; }
    }
    public class Center
    {
        public string crs { get; set; }
        public double x { get; set; }
        public double y { get; set; }
    }
    public class Coords
    {
        public Center center { get; set; }
    }
    public class Area0
    {
        public string name { get; set; }
        public Coords coords { get; set; }
    }
    public class Area1
    {
        public string name { get; set; }
        public Coords coords { get; set; }
        public string alias { get; set; }
    }
    public class Area2
    {
        public string name { get; set; }
        public Coords coords { get; set; }
    }
    public class Area3
    {
        public string name { get; set; }
        public Coords coords { get; set; }
    }
    public class Area4
    {
        public string name { get; set; }
        public Coords coords { get; set; }
    }
    public class Region
    {
        public Area0 area0 { get; set; }
        public Area1 area1 { get; set; }
        public Area2 area2 { get; set; }
        public Area3 area3 { get; set; }
        public Area4 area4 { get; set; }
    }
    public class Result
    {
        public string name { get; set; }
        public Code code { get; set; }
        public Region region { get; set; }
        public Land land { get; set; }
    }
    public class Addition0
    {
        public string type { get; set; }
        public string value { get; set; }
    }
    public class Addition1
    {
        public string type { get; set; }
        public string value { get; set; }
    }
    public class Addition2
    {
        public string type { get; set; }
        public string value { get; set; }
    }
    public class Addition3
    {
        public string type { get; set; }
        public string value { get; set; }
    }
    public class Addition4
    {
        public string type { get; set; }
        public string value { get; set; }
    }
    public class Land
    {
        public string type { get; set; }
        public string number1 { get; set; }
        public string number2 { get; set; }
        public Addition0 addition0 { get; set; }
        public Addition1 addition1 { get; set; }
        public Addition2 addition2 { get; set; }
        public Addition3 addition3 { get; set; }
        public Addition4 addition4 { get; set; }
        public Coords coords { get; set; }
        public string name { get; set; }
    }
    #endregion
}
