﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Push
    {
        /// <summary>
        /// PK값 (put only)
        /// </summary>
        public string push_cd { get; set; }
        /// <summary>
        /// 푸시 제목
        /// </summary>
        public string push_title { get; set; }
        /// <summary>
        /// 푸시 구분
        /// </summary>
        public string push_gbn { get; set; }
        /// <summary>
        /// 예약 발송 희망 일(YYYYMMDD)
        /// </summary>
        public string reserve_send_dt { get; set; }
        /// <summary>
        /// 발송시점구분 (A : 오전, P:오후)
        /// </summary>
        public string send_gbn { get; set; }
        /// <summary>
        /// 추가 정보1
        /// </summary>
        public string item1 { get; set; }
        /// <summary>
        /// 대상 구분 (D: DB, C: CSV 파일)
        /// </summary>
        public string object_gbn { get; set; }
        /// <summary>
        /// 발송 범위 구분 (M: 회원만, N: 비회원만, A: 전체)
        /// </summary>
        public string range_gbn { get; set; }
        /// <summary>
        /// 마케팅 동의 구분 (Y: 마케팅 동의만, N: 구분없음[전체])
        /// </summary>
        public string marketing_push_gbn { get; set; }
        /// <summary>
        /// 푸시 내용
        /// </summary>
        public string push_msg { get; set; }
        /// <summary>
        /// 전화번호 배열
        /// </summary>
        public IEnumerable<string> telno { get; set; }
        public string ucode { get; set; }
    }

    public class eventNoticeListForPush
    {
        public string notice_seq { get; set; }
        public string notice_title { get; set; }
        public string disp_fr_date { get; set; }
        public string disp_to_date { get; set; }
    }
}

