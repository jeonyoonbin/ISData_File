﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ChainCouponApp
    {
        public string coupon_type { get; set; }
        public string coupon_name { get; set; }
        public string chain_code { get; set; }
        public string chain_name { get; set; }
        public string order_min_amt { get; set; }
        public string pay_min_amt { get; set; }
        public string delivery_yn { get; set; }
        public string pack_yn { get; set; }
        public string display_st_date { get; set; }
        public string display_st_time { get; set; }
        public string display_exp_date { get; set; }
        public string display_exp_time { get; set; }
        public string use_yn { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
