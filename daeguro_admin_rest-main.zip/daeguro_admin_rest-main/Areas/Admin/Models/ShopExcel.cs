﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopExcel
    {
        public string ccName { get; set; }
        public string useGbn { get; set; }
        public string appOrderYn { get; set; }
        public string shopCd { get; set; }
        public string regNo { get; set; }
        public string shopName { get; set; }
        public string owner { get; set; }
        public string telNo { get; set; }
        public string regDate { get; set; }
        public string itemCD1 { get; set; }
        public string itemCD2 { get; set; }
        public string itemCD3 { get; set; }
        public string deliYn { get; set; }
        public string packingYn { get; set; }
        public string remainMinusYn { get; set; }
        public string shopID { get; set; }
        public string shopPass { get; set; }
        public string remainAmt { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string sidoName { get; set; }
        public string gunguName { get; set; }
        public string dongName { get; set; }
        public string salesManName { get; set; }
        public string operatorName { get; set; }
        public string memo { get; set; }
    }
}
