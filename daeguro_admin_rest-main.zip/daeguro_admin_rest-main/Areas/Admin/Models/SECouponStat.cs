﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class SECouponStat
    {
        public string daily { get; set; }
        public string set_shop_cnt { get; set; }
        public string pub_cnt { get; set; }
        public string use_cnt { get; set; }
        public string exp_cnt { get; set; }
        public string du_cnt { get; set; }
        public string left_cnt { get; set; }
    }
    
}
