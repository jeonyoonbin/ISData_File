﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopList
    {
        public string ccCode { get; set; }
        public string shopCd { get; set; }
        public string shopName { get; set; }
        public string serviceGbn { get; set; }
        //public string addr1 { get; set; }
        //public string addr2 { get; set; }
        public string regNo { get; set; }
        public string regNoYn { get; set; }
        public string useGbn { get; set; }
        public string appOrderYn { get; set; }
        public string imageStatus { get; set; }
        public string shopStatus { get; set; }
        public string openDate { get; set; }
        public string salesmanCode { get; set; }
        public string salesmanName { get; set; }
        public string operatorCode { get; set; }
        public string operatorName { get; set; }
        public string absentYn { get; set; }
        public string calcYn { get; set; }
        public string shopInfoYn { get; set; }
        public string menuYn { get; set; }
        public string deliYn { get; set; }
        public string tipYn { get; set; }
        public string saleYn { get; set; }
        public string basicInfoYn { get; set; }
        public string isCharged { get; set; }
        public string isPosInstalled { get; set; }
        public string isPosLogined { get; set; }
        public string loginTime { get; set; }
        public string apiComCode { get; set; }
        public string shopImageYn { get; set; }
        public string menuComplete { get; set; }
        public string franchiseCd { get; set; }
        public string reserveYn { get; set; }
        public string reserReqDate { get; set; }
        public string distanceYn { get; set; }
        public string flowerYn { get; set; }

        public string child_mealYn { get; set; }
        public string multi_shop_yn { get; set; }
        public string trad_yn { get; set; }
        public string m_shop_cd { get; set; }
        public string bundle_yn { get; set; }
    }

}
