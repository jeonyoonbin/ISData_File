﻿using System.Collections.Generic;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ResultBasic
    {
        public string code { get; set; }
        public string msg { get; set; }
    }

    public class ResultPlus
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string item { get; set; }
    }

    public class ResultPlus2
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string item { get; set; }
        public string item2 { get; set; }
        public string item3 { get; set; }
    }

    public class ResultBiztalk
    {
        public string result { get; set; }
        public string message { get; set; }
    }

    public class ResultShop
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string shop_cd { get; set; }
        public string api_com_code { get; set; }
    }

    //가맹점 생성결과
    public class ResultShop2
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string shopCd { get; set; }
        public string shopId { get; set; }
        public string apiComCode { get; set; }
    }

    //가맹점 매장정보 수정결과
    public class ResultShopInfo
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string jobGbn { get; set; }
        public string loginId { get; set; }
        public string jobGbn2 { get; set; }
        public string loginId2 { get; set; }
        public string apiComCode { get; set; }
    }

}
