﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OptionList
    {
        public string optionCd { get; set; }
        public string name { get; set; }
        public string memo { get; set; }
        public string fileName { get; set; }
        public string cost { get; set; }
        public string useYn { get; set; }
        public string noFlag { get; set; }
        public string adultOnly { get; set; }
    }
}
