﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class FcmResult
    {
        public string code { get; set; }
        public string msg { get; set; }
        public long multicast_id { get; set; }
        public int success { get; set; }
        public int canonical_ids { get; set; }
        public ItemResult[] results { get; set; }
    }

    public class FcmAndCustCode
    {
        public string device_gbn { get; set; }
        public string fcm_id { get; set; }
        public string cust_code { get; set; }
        public string telno { get; set; }
    }
}
