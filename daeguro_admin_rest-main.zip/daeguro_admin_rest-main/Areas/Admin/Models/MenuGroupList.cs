﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MenuGroupList
    {
        public string menuGroupCd { get; set; }
        public string menuGroupName { get; set; }
        public string menuNames { get; set; }
        public string useYn { get; set; }
        public string mainCount { get; set; }
    }
}
