﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class PushDetail
    {
        public string push_cd { get; set; }
        public string push_title { get; set; }
        public string send_gbn { get; set; }
        public string push_gbn { get; set; }
        public string boardseq { get; set; }
        public string notice_title { get; set; }
        public string tos_seq { get; set; }
        public string tos_memo { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string tab_gbn { get; set; }
        public string reserve_send_dt { get; set; }
        public string object_gbn { get; set; }
        public string range_gbn { get; set; }
        public string marketing_push_gbn { get; set; }
        public string push_msg { get; set; }
        public string status { get; set; }
        public string ins_date { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_name { get; set; }
    }
}

