﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class CouponPush
    {
        public string cust_code { get; set; }
        public string fcm_id { get; set; }
        public string device_gbn { get; set; }
        public string telno { get; set; }
        public string push_marketing_yn { get; set; }
        public string coupon_name { get; set; }
    }
}

