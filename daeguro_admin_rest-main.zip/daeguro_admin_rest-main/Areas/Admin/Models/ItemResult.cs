﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class ItemResult
    {
        public string message_id { get; set; }
        public string error { get; set; }
    }
}
