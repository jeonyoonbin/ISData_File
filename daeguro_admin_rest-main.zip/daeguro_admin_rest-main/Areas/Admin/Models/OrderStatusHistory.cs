﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OrderStatusHistory
    {
        public string status { get; set; }
        public string regTime { get; set; }
        public string modUser { get; set; }
        public string modDesc { get; set; }
    }
}
