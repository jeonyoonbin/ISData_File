﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    #region[자주쓰는 경조사어 관리]
    //자주쓰는 경조사어 목록
    public class CongratsBookmarkList
    {
        public string category_name { get; set; }
        public string bookmark_cd { get; set; }
        public string words_code { get; set; }
        public string contents { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class CongratsForBkList
    {
        public string category_name { get; set; }
        public string words_code { get; set; }
        public string contents { get; set; }
    }
    #endregion

    #region[경조사어 관리]
    //자주쓰는 경조사어 목록
    public class CongratsList
    {
        public string words_code { get; set; }
        public string contents { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
    #endregion

    public class CongratsCategoryList
    {
        public string category_code { get; set; }
        public string category_name { get; set; }
        public string use_gbn { get; set; }
    }
}
