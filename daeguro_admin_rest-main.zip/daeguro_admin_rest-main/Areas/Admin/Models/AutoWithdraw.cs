﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class AutoWithdraw
    {
        public string use_yn { get; set; }
        public string dt { get; set; }
        public string amt { get; set; }
    }
}
