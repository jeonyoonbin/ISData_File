﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class JwtConfig
    {
        public string Secret { get; set; }

    }
}
