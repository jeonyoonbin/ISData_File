﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class SendEventFCM
    {
        public string pushSeq { get; set; }
        public string title { get; set; }
        public string telno { get; set; }
        public string msg { get; set; }
        public string pushGbn { get; set; }
        public string item1 { get; set; }
        public string imageUrl { get; set; }
    }
}
