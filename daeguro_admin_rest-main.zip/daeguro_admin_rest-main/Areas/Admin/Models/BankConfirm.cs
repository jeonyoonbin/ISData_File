﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class BankConfirm
    {
        public string bankCode { get; set; }
        public string accountNo { get; set; }
        public string accOwner { get; set; }

        public string accountGb { get; } = "1";
        public string systemGb { get; } = "IS_DAEGU";
        public string mcode { get; } = "1";
        public string cccode { get; } = "1";
        public string ucode { get; } = "0";
    }
}
