﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class User
    {
        public string uCode { get; set; }
        public string ccCode { get; set; }
        public string name { get; set; }
        public string id { get; set; }
        public string password { get; set; }
        public string level { get; set; }
        public string mobile { get; set; }
        public string working { get; set; }
        public string memo { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
        public string insertDate { get; set; }
        public string retireDate { get; set; }
    }

    public class UserName
    {
        public string uCode { get; set; }
        public string name { get; set; }
        public string memo { get; set; }
    }
}
