﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class SaleTime // 가맹점 기본정보 조회
    {
        public string saleFromTime { get; set; }
        public string saleToTime { get; set; }
        public string saleNextDay { get; set; }
        public string appOrderYn { get; set; }
        public string useGbn { get; set; }
        public string happyPayUseGbn { get; set; }
        public string confirmYn { get; set; }
        public string confirmDate { get; set; }
        public string closedLogin { get; set; }
        public string supportFund { get; set; }
        public string reserveYn { get; set; }
        public string shopType { get; set; }
        /// <summary>
        /// 예약 승인일
        /// </summary>
        public string reserveApprovalDt { get; set; }
        /// <summary>
        /// 자동취소 사용 여부(Y: 기존 5분 취소 유지/ N: 즉시 접수 처리) 
        /// </summary>
        public string autoCancelGbn { get; set; }
        //public string autoCompYn { get; set; }
        public string autoCompType { get; set; }
        public string autoCompTerm { get; set; }
        public string autoCancelType { get; set; }
        public string autoCancelTerm { get; set; }
        public string autoCompTypeC { get; set; }
        public string autoCompTermC { get; set; }
        public string autoCancelTypeC { get; set; }
        public string autoCancelTermC { get; set; }
        public string pushGbn { get; set; }
        public string kakaoBiztalkGbn { get; set; }

        public string mall_use_gbn { get; set; }
        public string mall_tos_agre { get; set; }
        public string mall_tos_agre_dt { get; set; }

        public string kind_shop_status { get; set; }
        public string kind_shop_set_date { get; set; }
        public string kind_shop_pause_dt { get; set; }
        public string kind_shop_cancel_dt { get; set; }
        public string kind_shop_memo { get; set; }
        public string youtube_url { get; set; }
        public string child_meal_yn { get; set; }
        public string child_meal_cd { get; set; }
        public string min_amt_pass { get; set; }
        public string reg_no { get; set; }
        public string exchange_notice { get; set; }
        public string return_notice { get; set; }
        public string reject_notice { get; set; }

        public DeliNotice[] deli_notice { get; set; }
    }

    #region[가맹점 배송정보 관리]
    // 가맹점 배송정보 조회
    public class DeliNotice
    {
        public string deli_notice_code { get; set; }
        public string title { get; set; }
        public string content { get; set; }
        public string sort_seq { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    // 가맹점 배송정보 등록,수정,삭제, 순서변경
    public class DeliNoticePut
    {
        public string deli_notice_code { get; set; }
        public string title { get; set; }
        public string content { get; set; }
    }
    #endregion[가맹점 배송정보 관리]

}
