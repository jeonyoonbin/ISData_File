﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class CouponList
    {
        public string couponType { get; set; }
        public string couponName { get; set; }
        public string couponNo { get; set; }
        public string randomNo { get; set; }
        public string barCode { get; set; }
        public string status { get; set; }
        public string appCustCode { get; set; }
        public string custName { get; set; }
        public string telNo { get; set; }
        public string useAppCustCode { get; set; }
        public string useCustName { get; set; }
        public string useTelNo { get; set; }
        public string orderDate { get; set; }
        public string orderNo { get; set; }
        public string shopCd { get; set; }
        public string shopName { get; set; }
        public string serviceGbn { get; set; }
        public string useDate { get; set; }
        public string couponAmt { get; set; }
        public string linkUrl { get; set; }
        public string insDate { get; set; }
        public string insUCode { get; set; }
        public string insName { get; set; }
        public string expDate { get; set; }
        public string stDate { get; set; }
        public string confYN { get; set; }
        public string confDate { get; set; }
        public string confUCode { get; set; }
        public string confName { get; set; }
    }
}
