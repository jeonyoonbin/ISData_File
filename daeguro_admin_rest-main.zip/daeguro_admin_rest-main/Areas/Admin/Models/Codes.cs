﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Codes
    {
        public string codeGrp { get; set; }
        public string code { get; set; }
        public string codeName { get; set; }
        public string memo { get; set; }
        public string amt1 { get; set; }
        public string amt2 { get; set; }
        public string amt3 { get; set; }
        public string amt4 { get; set; }
        public string gbn1 { get; set; }
        public string gbn2 { get; set; }
        public string gbn3 { get; set; }
        public string value1 { get; set; }
        public string value2 { get; set; }
        public string value3 { get; set; }
        public string value4 { get; set; }
        public string value5 { get; set; }
        public string pubGbn { get; set; }
        public string useGbn { get; set; }
        public string testYn { get; set; }
        public string etc_code1 { get; set; }
        public string etc_code2 { get; set; }
        public string etc_code3 { get; set; }
        public string insUCode { get; set; }
        public string insName { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
    }

    public class CodesShopReqCategory
    {
        public string gbn_code { get; set; }
        public string gbn_name { get; set; }
        public string use_gbn { get; set; }        
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class CodesShopReqType
    {
        public string gbn_code { get; set; }
        public string gbn_name { get; set; }
        public string type_code { get; set; }
        public string type_name { get; set; }
        public string use_gbn { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
}
