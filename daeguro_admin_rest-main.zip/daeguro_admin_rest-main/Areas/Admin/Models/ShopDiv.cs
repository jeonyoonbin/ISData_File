﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopDiv
    {
        public string itemCd { get; set; }
        public string itemName { get; set; }
    }
}
