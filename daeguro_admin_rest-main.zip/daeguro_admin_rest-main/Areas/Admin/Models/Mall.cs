﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MallExist
    {
        public string user_id { get; set; }
        public string password { get; set; }
    }

    public record MallUser
    {
        public string mcode { get; set; }
        public string user_id { get; set; }
        public string password { get; set; }
        public string user_name { get; set; }
        public string tel_no { get; set; }
        public string email { get; set; }
        public string fk_shop_cd { get; set; }
        public string memo { get; set; }
        public string sido { get; set; }
        public string gugun { get; set; }
        public string dong { get; set; }
        public string address { get; set; }
        public string address_detail { get; set; }
    }

    public class ResultMall
    {
        public string code { get; set; }
        public string msg { get; set; }
        public ResultMallData data { get; set; }
    }

    public class ResultMallData
    {
        public string query_code { get; set; }
        public string query_msg { get; set; }
        public List<ResultBasic> parameter { get; set; }
    }


    public partial class MallResult
    {
        [JsonProperty("Result")]
        public List<MResult> result { get; set; }
    }

    public partial class MResult
    {
        [JsonProperty("result_info", NullValueHandling = NullValueHandling.Ignore)]
        public QueryResult result_info { get; set; }

        [JsonProperty("query_result", NullValueHandling = NullValueHandling.Ignore)]
        public QueryResult query_result { get; set; }
    }

    public partial class QueryResult
    {
        [JsonProperty("code")]
        public string code { get; set; }

        [JsonProperty("msg")]
        public string msg { get; set; }
    }
}
