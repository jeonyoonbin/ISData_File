﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    #region[매장정보 관리]
    public class ShopInfo
    {
        public string ccCode { get; set; }
        public string serviceGbn { get; set; }
        public string shopCd { get; set; }
        public string telNo { get; set; }
        public string itemCd1 { get; set; }
        public string itemCd2 { get; set; }
        public string itemCd3 { get; set; }
        public string appMinAmt { get; set; }
        public string shopType { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
        public string shopId { get; set; }
        public string shopPass { get; set; }
        public string shopImg { get; set; }
        public string bussImg { get; set; }
        public string idcardImg { get; set; }
        public string bankImg { get; set; }
        public string reserveYn { get; set; }
        public string useGbn { get; set; }
        public string deliTypeGbn { get; set; }
        public string multi_shop_yn { get; set; }
        public string multishop_cd { get; set; }
        public string representative_yn { get; set; }
        public string rep_shop_cd { get; set; }
        public string multishop_login_id { get; set; }
        public string rep_shop_name { get; set; }
        public string trad_yn { get; set; }
        public string bundle_yn { get; set; }
        public string trad_desc { get; set; }
        public string bundle_login_id { get; set; }
        public string m_shop_cd { get; set; }
        public string trad_name { get; set; }

    }

    public class ShopInfoPut
    {
        public string ccCode { get; set; }
        public string serviceGbn { get; set; }
        public string shopCd { get; set; }
        public string telNo { get; set; }
        public string itemCd1 { get; set; }
        public string itemCd2 { get; set; }
        public string itemCd3 { get; set; }
        public string appMinAmt { get; set; }
        public string shopType { get; set; }
        public string modUCode { get; set; }
        public string modName { get; set; }
        public string shopId { get; set; }
        public string shopPass { get; set; }
        public string shopImg { get; set; }
        public string bussImg { get; set; }
        public string idcardImg { get; set; }
        public string bankImg { get; set; }
        public string reserveYn { get; set; }
        public string useGbn { get; set; }
        public string deliTypeGbn { get; set; }
        public string multi_shop_yn { get; set; }
        public string multishop_cd { get; set; }
        //public string trad_yn { get; set; } 서비스 전통시장, 업종1 장보기이면 trad_yn = 'Y'
        public string bundle_yn { get; set; }
        public string trad_desc { get; set; }

    }
    #endregion[매장정보 관리]

    #region[가맹점 브레이크타임 관리]
    //브레이크타임 조회,등록,수정
    public class SbTime
    {
        public string shop_cd { get; set; }
        public string sb_gbn { get; set; }
        public string day_gbn { get; set; }
        public string open_time { get; set; }
        public string close_time { get; set; }
        public string next_day_yn { get; set; }
        public string use_gbn { get; set; }
    }
    public class SetSbTime
    {
        public string shop_cd { get; set; }
        public string sb_gbn { get; set; }
        public IEnumerable<string> day_gbn { get; set; }
        public IEnumerable<string> open_time { get; set; }
        public IEnumerable<string> close_time { get; set; }
        public IEnumerable<string> use_gbn { get; set; }
        public IEnumerable<string> next_day_yn { get; set; }
        public string ucode { get; set; }
        public string uname { get; set; }
    }
    #endregion[가맹점 브레이크타임 관리]
}
