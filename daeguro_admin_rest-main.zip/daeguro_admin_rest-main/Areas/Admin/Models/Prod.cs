﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    #region[상품그룹 관리]
    public class ProdGroupList
    {
        public string group_type { get; set; }
        public string prod_group_cd { get; set; }
        public string prod_group_name { get; set; }
        public string prod_names { get; set; }
        public string use_yn { get; set; }
        public string main_count { get; set; }
    }
    public class ProdGroup
    {
        public string group_type { get; set; }
        public string prod_group_cd { get; set; }
        public string prod_group_name { get; set; }
        public string prod_group_memo { get; set; }
        public string use_yn { get; set; }
    }

    public class ProdGroupPost
    {
        public string shop_cd { get; set; }
        public string prod_group_name { get; set; }
        public string prod_group_memo { get; set; }
        public string use_yn { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
    }

    public class ProdGroupPut
    {
        public string shop_cd { get; set; }
        public string prod_group_cd { get; set; }
        public string prod_group_name { get; set; }
        public string prod_group_memo { get; set; }
        public string use_yn { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
    #endregion[상품그룹 관리]

    #region[상품 관리]
    public class ProdList
    {
        public string cat_code { get; set; }
        public string cat_name { get; set; }
        public string prod_code { get; set; }
        public string name { get; set; }
        public string cost { get; set; }
        public string disc_yn { get; set; }
        public string disc_ratio { get; set; }
        public string amount { get; set; }
        public string file_name { get; set; }
        public string multi_cnt { get; set; }
        public string main_yn { get; set; }
        public string use_gbn { get; set; }
        public string no_flag { get; set; }
        public string prod_group_cd { get; set; }
        public string html { get; set; }
    }

    public class ProdDetail
    {
        public string prod_code { get; set; }
        public string name { get; set; }
        public string ribbon_card_yn { get; set; }
        public string cost { get; set; }
        public string amount { get; set; }
        public string disc_ratio { get; set; }
        public string disc_mark_gbn { get; set; }
        public string disc_st_dt { get; set; }
        public string disc_to_dt { get; set; }
        public string memo { get; set; }
        public string cat_code1 { get; set; }
        public string cat_code2 { get; set; }
        public string cat_code3 { get; set; }
        public string thema_code1 { get; set; }
        public string thema_code2 { get; set; }
        public string thema_code3 { get; set; }
        public string use_gbn { get; set; }
        public string no_flag { get; set; }
        public string main_yn { get; set; }
        public string description { get; set; }
        public string mark1_yn { get; set; }
        public string mark2_yn { get; set; }
        public string mark2_txt { get; set; }
        public string prod_group_cd { get; set; }
    }

    public class ProdPost
    {
        public string shop_cd { get; set; }
        public string name { get; set; }
        public string ribbon_card_yn { get; set; }
        public string cost { get; set; }
        public string amount { get; set; }
        public string disc_ratio { get; set; }
        public string disc_mark_gbn { get; set; }
        public string disc_st_dt { get; set; }
        public string disc_to_dt { get; set; }
        public string memo { get; set; }
        public string prod_group_cd { get; set; }
        //public IEnumerable<string> cat_code { get; set; }
        //public IEnumerable<string> thema_code { get; set; }
        public string cat_code1 { get; set; }
        public string cat_code2 { get; set; }
        public string cat_code3 { get; set; }
        public string thema_code1 { get; set; }
        public string thema_code2 { get; set; }
        public string thema_code3 { get; set; }
        public string use_gbn { get; set; }
        public string no_flag { get; set; }
        public string main_yn { get; set; }
        public string description { get; set; }
        public string mark1_yn { get; set; }
        public string mark2_yn { get; set; }
        public string mark2_txt { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
    }

    public class ProdPut
    {
        public string shop_cd { get; set; }
        public string prod_code { get; set; }
        public string name { get; set; }
        public string ribbon_card_yn { get; set; }
        public string cost { get; set; }
        public string amount { get; set; }
        public string disc_ratio { get; set; }
        public string disc_mark_gbn { get; set; }
        public string disc_st_dt { get; set; }
        public string disc_to_dt { get; set; }
        public string memo { get; set; }
        public string prod_group_cd { get; set; }
        //public IEnumerable<string> cat_code { get; set; }
        //public IEnumerable<string> thema_code { get; set; }
        public string cat_code1 { get; set; }
        public string cat_code2 { get; set; }
        public string cat_code3 { get; set; }
        public string thema_code1 { get; set; }
        public string thema_code2 { get; set; }
        public string thema_code3 { get; set; }
        public string use_gbn { get; set; }
        public string no_flag { get; set; }
        public string main_yn { get; set; }
        public string description { get; set; }
        public string mark1_yn { get; set; }
        public string mark2_yn { get; set; }
        public string mark2_txt { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    #endregion[상품 관리]

    #region[(장보기)상품 관리]
    public class BundleProdPost
    {
        public string shop_cd { get; set; }
        public string name { get; set; }
        public string cost { get; set; }
        public string amount { get; set; }
        public string disc_ratio { get; set; }
        public string disc_mark_gbn { get; set; }
        public string disc_st_dt { get; set; }
        public string disc_to_dt { get; set; }
        public string memo { get; set; }
        public string cat_code1 { get; set; }
        public string cat_code2 { get; set; }
        public string cat_code3 { get; set; }
        public string use_gbn { get; set; }
        public string no_flag { get; set; }
        public string main_yn { get; set; }
        public string description { get; set; }
        public string mark2_yn { get; set; }
        public string mark2_txt { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
    }

    public class BundleProdPut
    {
        public string shop_cd { get; set; }
        public string prod_code { get; set; }
        public string name { get; set; }
        public string cost { get; set; }
        public string amount { get; set; }
        public string disc_ratio { get; set; }
        public string disc_mark_gbn { get; set; }
        public string disc_st_dt { get; set; }
        public string disc_to_dt { get; set; }
        public string memo { get; set; }
        public string cat_code1 { get; set; }
        public string cat_code2 { get; set; }
        public string cat_code3 { get; set; }
        public string use_gbn { get; set; }
        public string no_flag { get; set; }
        public string main_yn { get; set; }
        public string description { get; set; }
        public string mark2_yn { get; set; }
        public string mark2_txt { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }
    #endregion[(장보기)상품 관리]

    #region[상품 옵션그룹 연결 관리]
    public class SetProdOpt
    {
        public string shopCd { get; set; }
        public string prodCd { get; set; }
        public IEnumerable<string> optGrpCd { get; set; }
        public string uCode { get; set; }
        public string uName { get; set; }
    }

    public class GetProdOption
    {
        public string prodOptGrpCd { get; set; }
        public string optGrpCd { get; set; }
        public string OptGrpName { get; set; }
        public string prodCd { get; set; }
        public string sortNo { get; set; }
        public string optNames { get; set; }
    }

    public class DeleteProdOption
    {
        public string shopCd { get; set; }
        public string prodCd { get; set; }
        public string optGrpCd { get; set; }
        public string prodOptGrpCd { get; set; }
        public string uCode { get; set; }
        public string uName { get; set; }
    }

    public class OptGrpSelect
    {
        public string? selected { get; set; }
        public string? optGrpCd { get; set; }
        public string? name { get; set; }
        public string? minCount { get; set; }
        public string? multiCount { get; set; }
        public string? addYn { get; set; }
        public string? useGbn { get; set; }
        public string? optNames { get; set; }
    }
    #endregion[상품 옵션그룹 연결 관리]

    #region[상품 옵션그룹 관리]
    public class ProdOGroup
    {
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string addYn { get; set; }
        public string useGbn { get; set; }
        public string optionNames { get; set; }
    }

    public class ProdOGroupDetail
    {
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string addYn { get; set; }
        public string useGbn { get; set; }
    }

    public class ProdOGroupPost
    {
        public string shopCd { get; set; }
        public string optionGroupName { get; set; }
        public string useGbn { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string insUcode { get; set; }
        public string insName { get; set; }
    }

    public class ProdOGroupPut
    {
        public string shopCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string useGbn { get; set; }
        public string minCount { get; set; }
        public string maxCount { get; set; }
        public string modUcode { get; set; }
        public string modName { get; set; }
    }
    #endregion[상품 옵션그룹 관리]

    #region[상품 옵션 관리]
    public class ProdOption
    {
        public string optionCd { get; set; }
        public string name { get; set; }
        public string memo { get; set; }
        public string cost { get; set; }
        public string useGbn { get; set; }
        public string noFlag { get; set; }
    }

    public class ProdOptionDetail
    {
        public string optionGroupCd { get; set; }
        public string optionCd { get; set; }
        public string optionName { get; set; }
        public string optionMemo { get; set; }
        public string cost { get; set; }
        public string useGbn { get; set; }
        public string noFlag { get; set; }
    }

    public class ProdOptionPost
    {
        public string shopCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionName { get; set; }
        public string optionMemo { get; set; }
        public string cost { get; set; }
        public string useGbn { get; set; }
        public string noFlag { get; set; }
        public string insUcode { get; set; }
        public string insName { get; set; }
    }

    public class ProdOptionPut
    {
        public string optionCd { get; set; }
        public string optionName { get; set; }
        public string optionMemo { get; set; }
        public string cost { get; set; }
        public string useGbn { get; set; }
        public string noFlag { get; set; }
        public string modUcode { get; set; }
        public string modName { get; set; }
    }
    #endregion[상품 옵션 관리]

    #region[상품 이미지 관리]
    public class ProdMultiList
    {
        public string seq { get; set; }
        public string file_name { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class ProdMultiImg
    {
        public string shop_cd { get; set; }
        public string prod_image_seq { get; set; }
        public string prod_code { get; set; }
        public string file_name { get; set; }
    }
    #endregion[상품 이미지 관리]

    #region[상품 설명 html 관리]
    public class ProdHtmlPost
    {
        public string prod_code { get; set; }
        public IFormFile formFile { get; set; }
        public string ucode { get; set; }
        public string uname { get; set; }
    }
    #endregion[상품 설명 html 관리]

    #region[변경이력]
    public class OptionHist
    {
        public string seq { get; set; }
        public string optGrpCd { get; set; }
        public string optionCd { get; set; }
        public string histGbn { get; set; }
        public string histDate { get; set; }
        public string memo { get; set; }
    }

    #endregion[변경이력]
}
