﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class ChainName
    {
        public string code { get; set; }
        public string name { get; set; }
        public string use_gbn { get; set; }
    }
}
