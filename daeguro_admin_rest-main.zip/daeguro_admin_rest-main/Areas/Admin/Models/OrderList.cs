﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OrderList
    {
        public string orderNo { get; set; }
        public string payGbn { get; set; }
        public string orderTime { get; set; }
        public string shopTelNo { get; set; }
        public string regNo { get; set; }
        public string serviceGbn { get; set; }
        public string shopName { get; set; }
        public string shopCd { get; set; }
        public string orderAmount { get; set; }
        public string status { get; set; }
        public string cancelType { get; set; }
        public string cancelReason { get; set; }
        public string custCode { get; set; }
        public string customerTelNo { get; set; }
        public string tuid { get; set; }
        public string cardName { get; set; }
        public string appNo { get; set; }
        public string cardAmount { get; set; }
        public string directPay { get; set; }
        public string custIdGbn { get; set; }
        public string posInstalled { get; set; }
        public string posLogined { get; set; }
        public string apiComCode { get; set; }
        public string packOrderYn { get; set; }
    }
}
