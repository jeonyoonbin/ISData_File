﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class RestError
    {
        public string seq { get; set; }
        public string div { get; set; }
        public string position { get; set; }
        public string msg { get; set; }
        public string insert_time { get; set; }
    }
}
