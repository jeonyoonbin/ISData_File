﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    #region[결제혜택]
    public class PaymentList
    {
        public string pay_gbn { get; set; }
        public string app_pay_gbn { get; set; }
        public string pay_name { get; set; }
        public string use_gbn { get; set; }
        public string benefit_yn { get; set; }
        public string notice_yn { get; set; }

    }

    public class PaymentDetail
    {
        public string pay_gbn { get; set; }
        public string app_pay_gbn { get; set; }
        public string pay_name { get; set; }
        public string use_gbn { get; set; }
        public string login_yn { get; set; }
        public string benefit_yn { get; set; }
        public string notice_yn { get; set; }
        public string notice { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }

    }

    public class PaymentPut
    {
        public string pay_gbn { get; set; }
        public string app_pay_gbn { get; set; }
        public string benefit_yn { get; set; }
        public string notice_yn { get; set; }
        public string notice { get; set; }
        public string mod_ucode { get; set; }
    }
    #endregion[결제혜택]

    #region[결제장애공재]
    public class PaymentEm
    {
        public string pay_gbn { get; set; }
        public string app_pay_gbn { get; set; }
        public string pay_name { get; set; }
        public string able_yn { get; set; }
        public string disorder_msg { get; set; }

    }

    public class PaymentEmPut
    {
        public string pay_gbn { get; set; }
        public string app_pay_gbn { get; set; }
        public string able_yn { get; set; }
        public string disorder_msg { get; set; }
    }
    #endregion[결제장애공재]
}
