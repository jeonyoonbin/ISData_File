﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class AddNotice
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string fileName { get; set; }
    }
}
