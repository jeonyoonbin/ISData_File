﻿namespace DG_App_Rest.Areas.Admin.Models
{
    public class ShopCoupon
    {
        public string coupon_type { get; set; }
        public string coupon_name { get; set; }
        public string display_st_date { get; set; }
        public string display_end_date { get; set; }
        public string exp_set_date { get; set; }
        public string ins_date { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_name { get; set; }
        public ShopCouponItem[] coupon_item { get; set; }
    }
}
