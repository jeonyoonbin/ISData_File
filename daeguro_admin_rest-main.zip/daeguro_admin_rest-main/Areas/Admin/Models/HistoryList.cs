﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class HistoryList
    {
        public string no { get; set; }
        public string insertDate { get; set; }
        public string memo { get; set; }
    }

    public class Hist
    {
        public string seq { get; set; }
        public string hist_date { get; set; }
        public string hist_gbn { get; set; }
        public string memo { get; set; }
    }
}
