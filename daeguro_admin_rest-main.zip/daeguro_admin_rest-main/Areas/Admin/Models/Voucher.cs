﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class VoucherNameList
    {
        public string prsc_gbn { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
    }

    public class Voucher
    {
        public string voucher_type { get; set; }
        public IEnumerable<string> reciever { get; set; }
        public IEnumerable<string> telno { get; set; }
        //public string card_msg_yn { get; set; }
        public string card_img { get; set; }
        public string card_msg { get; set; }
        public string ucode { get; set; }
    }

    public class VoucherRefundData
    {
        public string account { get; set; }
        public string bankcode { get; set; }
        public string bankname { get; set; }
        public string acc_owner { get; set; }
    }

    public class VoucherRefund
    {
        public string voucher_no { get; set; }
        public string refund_amt { get; set; }
        public string account { get; set; }
        public string bankcode { get; set; }
        public string acc_owner { get; set; }
        public string ucode { get; set; }
        public string uname { get; set; }
    }

    public class VoucherRefundList
    {
        public string refund_seq { get; set; }
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string voucher_no { get; set; }
        public string r_req_dt { get; set; }
        public string r_comp_dt { get; set; }
        public string r_amt { get; set; }
        public string acc_owner { get; set; }
        public string bankcode { get; set; }
        public string bankname { get; set; }
        public string r_account { get; set; }
        public string status { get; set; }
        public string r_req_gbn { get; set; }
        public string result_msg { get; set; }
    }

    public class VoucherDetail
    {
        public string voucher_name { get; set; }
        public string voucher_no { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_remain_amt { get; set; }
        public string refund_amt { get; set; }
        public string use_amt { get; set; }
        public string reg_date { get; set; }
        public string reg_exp_date { get; set; }
        public string use_exp_date { get; set; }
        public string send_date { get; set; }
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string cust_telno { get; set; }
        public string bankname { get; set; }
        public string r_account { get; set; }
        public VoucherHist[] hist { get; set; }
    }

    public class VoucherHist
    {
        public string hist_seq { get; set; }
        public string hist_date { get; set; }
        public string memo { get; set; }
    }

    public class VoucherList
    {
        public string voucher_seq { get; set; }
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string prsc_gbn { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string sale_no { get; set; }
        public string voucher_no { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_remain_amt { get; set; }
        public string status { get; set; }
        public string reg_date { get; set; }
        public string reg_exp_date { get; set; }
        public string use_exp_date { get; set; }
        public string cust_code { get; set; }
        public string cust_telno { get; set; }
        public string cust_name { get; set; }
        public string receive_telno { get; set; }
        public string card_reciever { get; set; }
        public string buy_ccode { get; set; }
        public string buy_telno { get; set; }
        public string buy_name { get; set; }
        public string refund_acc_yn { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        //public string mod_date { get; set; }
        //public string mod_ucode { get; set; }
        //public string mod_name { get; set; }
    }

    #region [기존 비즈톡 모델]
    public class SendBiztalk
    {
        public string msgid { get; set; }
        public string message_type { get; set; }
        public string receiver_num { get; set; }
        public string message { get; set; }
        public string template_code { get; set; }
        public string reserved_time { get; set; }
        public BiztalkBtn button1 { get; set; }
    }

    public class BiztalkBtn
    {
        public string name { get; set; }
        public string type { get; set; }
        public string scheme_ios { get; set; }
        public string scheme_android { get; set; }
    }
    #endregion [기존 비즈톡 모델]

    #region [그룹코드 관리]
    public class VoucherGroupList
    {
        public string seq { get; set; }
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string prsc_gbn { get; set; }
        public string memo { get; set; }
        public string use_yn { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherGroupDetail
    {
        public string seq { get; set; }
        public string use_yn { get; set; }
        public string test_yn { get; set; }
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string prsc_gbn { get; set; }
        public string memo { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherGroup
    {
        public string seq { get; set; }
        public string prsc_gbn { get; set; }
        public string use_yn { get; set; }
        public string test_yn { get; set; }
        //public string group_cd { get; set; }
        public string group_name { get; set; }
        public string memo { get; set; }
        public string ucode { get; set; }
    }
    #endregion

    #region [코드 관리]
    public class VoucherCodeList
    {
        public string seqno { get; set; }
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string memo { get; set; }
        public string use_yn { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_notice { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherCodeDetail
    {
        public string seqno { get; set; }
        public string group_cd { get; set; }
        public string use_yn { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string promotion_yn { get; set; }
        public string budget { get; set; }
        public string disc_gbn { get; set; }
        public string disc_range { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_notice { get; set; }
        public string memo { get; set; }
        public string thumb_url { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherCode
    {
        public string seqno { get; set; }
        public string group_cd { get; set; }
        public string use_yn { get; set; }
        //public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string promotion_yn { get; set; }
        public string budget { get; set; }
        public string disc_gbn { get; set; }
        public string disc_range { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_notice { get; set; }
        public string memo { get; set; }
        public string ucode { get; set; }

    }
    #endregion

    #region [카드 이미지 카테고리 관리]
    public class VoucherImgCategoryList
    {
        public string category_cd { get; set; }
        public string category_name { get; set; }
        public string memo { get; set; }
        //public string use_gbn { get; set; }
        public string app_visible_yn { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherImgCategoryDetail
    {
        //public string use_gbn { get; set; }
        public string app_visible_yn { get; set; }
        public string category_cd { get; set; }
        public string category_name { get; set; }
        public string memo { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherImgCategory
    {
        public string category_cd { get; set; }
        public string category_name { get; set; }
        //public string use_gbn { get; set; }
        public string app_visible_yn { get; set; }
        public string memo { get; set; }
        public string ucode { get; set; }
    }

    public class VoucherImgCategorySort
    {
        public string sort_seq { get; set; }
        public string category_cd { get; set; }
        public string category_name { get; set; }
    }
    #endregion

    #region [카드 이미지 관리]
    public class VoucherImgList
    {
        public string img_code { get; set; }
        public string type_gbn { get; set; }
        public string app_visible_yn { get; set; }
        public string use_gbn { get; set; }
        public string category_cd { get; set; }
        public string img_url { get; set; }
        public string memo { get; set; }
        public string ins_date { get; set; }
        public string ins_ucode { get; set; }
        public string ins_name { get; set; }
        public string mod_date { get; set; }
        public string mod_ucode { get; set; }
        public string mod_name { get; set; }
    }

    public class VoucherImg
    {
        public string img_code { get; set; }
        public string type_gbn { get; set; }
        public string use_gbn { get; set; }
        public string category_cd { get; set; }
        public string img_url { get; set; }
        public string memo { get; set; }
        public string ucode { get; set; }
    }

    public class VoucherImgChoice
    {
        public string img_code { get; set; }
        //public string type_gbn { get; set; }
        //public string use_gbn { get; set; }
        public string img_url { get; set; }
        //public string memo { get; set; }
    }
    #endregion

    #region[판매집계표]
    public class VoucherCalcList
    {
        public string prsc_gbn { get; set; }
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string dt { get; set; }
        public string remain_amt { get; set; }
        public string reg_amt { get; set; }
        public string reg_cnt { get; set; }
        public string payment_amt { get; set; }
        public string disc_amt { get; set; }
        public string use_amt { get; set; }
        public string cancel_amt { get; set; }
        public string comp_cnt { get; set; }
        public string reuse_amt { get; set; }
        public string re_cancel_amt { get; set; }
        public string r_comp_cnt { get; set; }
        public string refund_amt { get; set; }
        public string refund_fee { get; set; }
        public string refund_cnt { get; set; }
    }

    public class VoucherCalcDetail
    {
        public string group_cd { get; set; }
        public string group_name { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string voucher_no { get; set; }
        public string status { get; set; }
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string ins_date { get; set; }
        public string reg_date { get; set; }
        public string use_exp_date { get; set; }
        public string remain_amt { get; set; }
        public string reg_amt { get; set; }
        public string payment_amt { get; set; }
        public string disc_amt { get; set; }
        public string use_amt { get; set; }
        public string cancel_amt { get; set; }
        public string reuse_amt { get; set; }
        public string re_cancel_amt { get; set; }
        public string refund_amt { get; set; }
        public string refund_fee { get; set; }
    }

    //사용내역
    public class VoucherUseList
    {
        public string charge_date { get; set; }
        public string order_no { get; set; }
        public string service_gbn { get; set; }
        public string charge_amt { get; set; }
    }
    #endregion

    #region[구매내역]
    public class VoucherBuyList
    {
        public string sale_date { get; set; }
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string telno { get; set; }
        public string cnt { get; set; }
        public string amt { get; set; }
        public string disc_amt { get; set; }
    }

    public class VoucherBuyDetail
    {
        public string sale_no { get; set; }
        public string tuid { get; set; }
        public string org_app_ymd { get; set; }
        public string pay_gbn { get; set; }
        public string payment_amt { get; set; }
        public string cancel_amt { get; set; }
        public string cust_telno { get; set; }

        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string cnt { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_no { get; set; }
        public string purchase_price { get; set; }
        public string disc_amt { get; set; }
        public string card_reciever { get; set; }
        public string use_amt { get; set; }
        public string refund_amt { get; set; }
        public string status { get; set; }
    }
    #endregion

    #region[상품권 취소 처리]
    public class VoucherCancelWait
    {
        public string job_gbn { get; set; }
        public string sale_no { get; set; }
        public IEnumerable<string> voucher_no { get; set; }
        //public string card_msg_yn { get; set; }
        public string ucode { get; set; }
        public string uname{ get; set; }        
    }

    public class VoucherAfterApproval
    {
        public string job_gbn { get; set; }
        public string sale_no { get; set; }
        public IEnumerable<string> voucher_no { get; set; }
        public string tuid { get; set; }
        public string cancel_amt { get; set; }
        public string cancel_code { get; set; }
        public string card_cancel_time { get; set; }
        public string cancel_reason { get; set; }        
        public string ucode { get; set; }
        public string uname { get; set; }        
    }
    #endregion

    #region[발송내역]
    public class VoucherSendList
    {
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string voucher_no { get; set; }
        public string voucher_amt { get; set; }
        public string send_gbn { get; set; }
        public string result_msg { get; set; }
        public string send_date { get; set; }
        public string status { get; set; }
    }
    #endregion

    #region[유효기간내역]
    public class VoucherExpList
    {
        public string prsc_gbn { get; set; }
        public string reg_date { get; set; }
        public string use_exp_date { get; set; }
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_remain_amt { get; set; }
        public string voucher_no { get; set; }
        public string send_yn { get; set; }
    }

    #endregion

    #region[결제취소 내역]
    public class VoucherCancelList
    {
        public string cust_code { get; set; }
        public string cust_name { get; set; }
        public string telno { get; set; }
        public string sale_no { get; set; }
        public string voucher_type { get; set; }
        public string voucher_name { get; set; }
        public string voucher_amt { get; set; }
        public string voucher_no { get; set; }
        public string after_exp_dt { get; set; }
        public string partial_cancel_dt { get; set; }
        public string status { get; set; }
        public string fail_reason { get; set; }
    }

    #endregion
}
