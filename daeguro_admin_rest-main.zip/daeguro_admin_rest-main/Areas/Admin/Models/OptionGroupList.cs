﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class OptionGroupList
    {
        public string menuOptionGroupCd { get; set; }
        public string optionGroupCd { get; set; }
        public string optionGroupName { get; set; }
        public string optionNames { get; set; }
    }
}
