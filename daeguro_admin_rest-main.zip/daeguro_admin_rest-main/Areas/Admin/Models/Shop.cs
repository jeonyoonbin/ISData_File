﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Shop
    {
        public string ccCode { get; set; }
        public string shopCd { get; set; }
        public string shopName { get; set; }
        public string telNo { get; set; }
        public string owner { get; set; }
        public string addr1 { get; set; }
        public string addr2 { get; set; }
        public string zipCode { get; set; }
        public string regNo { get; set; }
        public string useGbn { get; set; }
        public string openDate { get; set; }
        public string closedDate { get; set; }
        public string vBankCd { get; set; }
        public string vAccount { get; set; }
        public string bankCode { get; set; }
        public string accountNo { get; set; }
        public string accOwner { get; set; }
        public string payConfirm { get; set; }
        public string memo { get; set; }
        public string shopId { get; set; }
        public string shopPass { get; set; }
        public string mobile { get; set; }
        public string sidoName { get; set; }
        public string gunguName { get; set; }
        public string dongName { get; set; }
        public string destJibun { get; set; }
        public string roadDestDong { get; set; }
        public string roadDestAddr { get; set; }
        public string roadDestBuilding { get; set; }
        public string loc { get; set; }
        public List<AddFile> files { get; set; }
    }

    public class ShopService
    {
        public string service_gbn { get; set; }
        public string service_name { get; set; }
    }
}
