﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class CustInquiryList
    {
        public string seqno { get; set; }
        public string service_name { get; set; }
        public string inquiry_name { get; set; }
        public string contents { get; set; }
        public string ins_date { get; set; }
    }

    public class CustInquiryDetail
    {
        public string seqno { get; set; }
        public string service_gbn { get; set; }
        public string service_name { get; set; }
        public string inquiry_gbn { get; set; }
        public string inquiry_name { get; set; }
        public string os_type { get; set; }
        public string os_version { get; set; }
        public string device_model { get; set; }
        public string app_version { get; set; }
        public string contents { get; set; }
        public string ins_date { get; set; }
        public string cust_code { get; set; }
        public string img_file1 { get; set; }
        public string img_file2 { get; set; }
        public string img_file3 { get; set; }
        public string img_file4 { get; set; }
        public string img_file5 { get; set; }
    }
}
