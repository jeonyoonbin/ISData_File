﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class CcCalcSum
    {
        public string COUNT { get; set; }
        public string SUM_IN_AMT { get; set; }
        public string SUM_OUT_AMT { get; set; }
        public string SUM_PRE_AMT { get; set; }
        public string TOT_SUM_PRE_AMT { get; set; }
    }

    public class CcCalcExcel
    {
        public string order_no { get; set; }
        public string order_time { get; set; }
        public string charge_date { get; set; }
        public string charge_gbn_nm { get; set; }
        public string ccname { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string in_amt { get; set; }
        public string out_amt { get; set; }
        public string pre_amt { get; set; }
        public string memo { get; set; }
    }

    public class ShopCalcExcel
    {
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string all_amt { get; set; }
        public string take_count { get; set; }
        public string in_amt { get; set; }
        public string p_amt { get; set; }
        public string k_amt { get; set; }
        public string take_amt { get; set; }
        public string remain_amt { get; set; }
    }

    public class ShopCalcExcel2
    {
        public string order_no { get; set; }
        public string charge_date { get; set; }
        public string charge_gbn_nm { get; set; }
        public string ccname { get; set; }
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string in_amt { get; set; }
        public string out_amt { get; set; }
        public string pre_amt { get; set; }
        public string memo { get; set; }
    }
}
