﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class Maps
    {
        public string shop_cd { get; set; }
        public string shop_name { get; set; }
        public string gungu_name { get; set; }
        public string lon { get; set; }
        public string lat { get; set; }
    }
}
