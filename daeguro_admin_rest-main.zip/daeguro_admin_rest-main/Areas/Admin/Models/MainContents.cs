﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class MainContents
    {
        public string cartegory_gbn { get; set; }
        public string contents_cd { get; set; }
        public string contents_title { get; set; }
        public string disp_gbn { get; set; }
        public string main_url { get; set; }
        public string url_title { get; set; }
        public string emoji_code { get; set; }
        public string thumbnail_url { get; set; }
        public string ins_ucode { get; set; }
        public string mod_ucode { get; set; }
    }
}
