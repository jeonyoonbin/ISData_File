﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DG_App_Rest.Areas.Admin.Models
{
    public class SiGuDong
    {
        public string siguName { get; set; }
        public string dongName { get; set; }
    }
}
