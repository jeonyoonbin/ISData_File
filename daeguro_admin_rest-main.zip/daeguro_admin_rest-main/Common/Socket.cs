﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace DG_App_Rest.Common
{
    public class Socket : Hub
    {
        public async Task SendMessage(string message)
        {
            await Clients.All.SendAsync("newMessage", message);
        }
    }
}
